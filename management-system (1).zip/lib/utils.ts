import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// Utility function to check if user has required rank or is admin
export function hasRequiredRank(userRank: string, requiredRank: string, isAdmin = false): boolean {
  // Admin always has access
  if (isAdmin) return true

  const ranks = [
    "Cadet",
    "Police Officer",
    "Police Officer II",
    "Sergeant",
    "Lieutenant",
    "Captain",
    "Deputy Chief",
    "Assistant Sheriff",
    "Undersheriff",
    "Sheriff",
  ]

  const userRankIndex = ranks.indexOf(userRank)
  const requiredRankIndex = ranks.indexOf(requiredRank)

  // If ranks not found, deny access
  if (userRankIndex === -1 || requiredRankIndex === -1) return false

  // User rank must be equal or higher than required rank
  return userRankIndex >= requiredRankIndex
}
