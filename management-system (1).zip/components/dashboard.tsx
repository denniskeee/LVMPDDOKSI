"use client"

import { useState } from "react"
import { AppSidebar } from "@/components/app-sidebar"
import { HomePage } from "@/components/pages/home-page"
import { DocsPage } from "@/components/pages/docs-page"
import { ReportsPage } from "@/components/pages/reports-page"
import { LeaveRequestPage } from "@/components/pages/leave-request-page"
import { VehicleRequestPage } from "@/components/pages/vehicle-request-page"
import { UprRequestPage } from "@/components/pages/upr-request-page"
import { VehiclesPage } from "@/components/pages/vehicles-page"
import { SeizedCarsPage } from "@/components/pages/seized-cars-page"
import { WeaponReportPage } from "@/components/pages/weapon-report-page"
import { UserManagementPage } from "@/components/pages/user-management-page"
import { IncomingRequestsPage } from "@/components/pages/incoming-requests-page"
import { SidebarProvider, SidebarInset, SidebarTrigger } from "@/components/ui/sidebar"
import { Separator } from "@/components/ui/separator"
import { Button } from "@/components/ui/button"
import { LogOut } from "lucide-react"

interface DashboardProps {
  user: any
  onLogout: () => void
}

export function Dashboard({ user, onLogout }: DashboardProps) {
  const [currentPage, setCurrentPage] = useState("home")

  const renderPage = () => {
    switch (currentPage) {
      case "home":
        return <HomePage user={user} onPageChange={setCurrentPage} />
      case "docs":
        return <DocsPage user={user} />
      case "reports":
        return <ReportsPage user={user} />
      case "leave-requests":
        return <LeaveRequestPage user={user} />
      case "vehicle-requests":
        return <VehicleRequestPage user={user} />
      case "upr-requests":
        return <UprRequestPage user={user} />
      case "vehicles":
        return <VehiclesPage />
      case "seized-cars":
        return <SeizedCarsPage />
      case "weapon-reports":
        return <WeaponReportPage user={user} />
      case "user-management":
        return <UserManagementPage />
      case "incoming-requests":
        return <IncomingRequestsPage user={user} />
      default:
        return <HomePage user={user} onPageChange={setCurrentPage} />
    }
  }

  return (
    <SidebarProvider>
      <AppSidebar user={user} currentPage={currentPage} onPageChange={setCurrentPage} />
      <SidebarInset>
        <header className="flex h-16 shrink-0 items-center gap-2 border-b px-4">
          <SidebarTrigger className="-ml-1" />
          <Separator orientation="vertical" className="mr-2 h-4" />
          <div className="flex-1">
            <h1 className="font-semibold">Rendőrségi Irányítási Rendszer</h1>
          </div>
          <Button variant="ghost" size="sm" onClick={onLogout}>
            <LogOut className="w-4 h-4 mr-2" />
            Kijelentkezés
          </Button>
        </header>
        <div className="flex flex-1 flex-col gap-4 p-4">{renderPage()}</div>
      </SidebarInset>
    </SidebarProvider>
  )
}
