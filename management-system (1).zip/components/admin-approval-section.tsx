"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Textarea } from "@/components/ui/textarea"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { CheckCircle, XCircle, Clock, UserCheck, Calendar } from "lucide-react"

interface AdminApprovalSectionProps {
  users: any[]
  setUsers: (users: any[]) => void
  leaveRequests: any[]
  setLeaveRequests: (requests: any[]) => void
}

export function AdminApprovalSection({ users, setUsers, leaveRequests, setLeaveRequests }: AdminApprovalSectionProps) {
  const [rejectionReason, setRejectionReason] = useState("")
  const [selectedRequestId, setSelectedRequestId] = useState<number | null>(null)
  const [isRejectDialogOpen, setIsRejectDialogOpen] = useState(false)

  const pendingUsers = users.filter((user) => !user.approved)
  const pendingLeaveRequests = leaveRequests.filter((req) => req.status === "Jóváhagyás függőben")

  const handleApproveUser = (userId: number) => {
    const updatedUsers = users.map((user) =>
      user.id === userId ? { ...user, approved: true, approvedAt: new Date().toISOString() } : user,
    )
    setUsers(updatedUsers)
    localStorage.setItem("users", JSON.stringify(updatedUsers))
  }

  const handleRejectUser = (userId: number) => {
    const updatedUsers = users.filter((user) => user.id !== userId)
    setUsers(updatedUsers)
    localStorage.setItem("users", JSON.stringify(updatedUsers))
  }

  const handleApproveLeaveRequest = (requestId: number) => {
    const updatedRequests = leaveRequests.map((req) =>
      req.id === requestId ? { ...req, status: "Elfogadva", approvedAt: new Date().toISOString() } : req,
    )
    setLeaveRequests(updatedRequests)
    localStorage.setItem("leaveRequests", JSON.stringify(updatedRequests))
  }

  const handleRejectLeaveRequest = () => {
    if (selectedRequestId && rejectionReason.trim()) {
      const updatedRequests = leaveRequests.map((req) =>
        req.id === selectedRequestId
          ? {
              ...req,
              status: "Elutasítva",
              rejectionReason: rejectionReason.trim(),
              rejectedAt: new Date().toISOString(),
            }
          : req,
      )
      setLeaveRequests(updatedRequests)
      localStorage.setItem("leaveRequests", JSON.stringify(updatedRequests))

      // Reset dialog state
      setRejectionReason("")
      setSelectedRequestId(null)
      setIsRejectDialogOpen(false)
    }
  }

  const openRejectDialog = (requestId: number) => {
    setSelectedRequestId(requestId)
    setIsRejectDialogOpen(true)
  }

  const calculateDays = (start: string, end: string) => {
    if (!start || !end) return 0
    const startDate = new Date(start)
    const endDate = new Date(end)
    const diffTime = Math.abs(endDate.getTime() - startDate.getTime())
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1
    return diffDays
  }

  return (
    <div className="space-y-6">
      {/* Pending User Registrations */}
      {pendingUsers.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <UserCheck className="h-5 w-5" />
              Jóváhagyásra váró regisztrációk ({pendingUsers.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Név</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Beosztás</TableHead>
                  <TableHead>Jelvényszám</TableHead>
                  <TableHead>Regisztráció dátuma</TableHead>
                  <TableHead>Műveletek</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {pendingUsers.map((user) => (
                  <TableRow key={user.id}>
                    <TableCell className="font-medium">{user.name}</TableCell>
                    <TableCell>{user.email}</TableCell>
                    <TableCell>{user.rank}</TableCell>
                    <TableCell>{user.badgeNumber}</TableCell>
                    <TableCell>{user.joinedDate}</TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          onClick={() => handleApproveUser(user.id)}
                          className="bg-green-600 hover:bg-green-700"
                        >
                          <CheckCircle className="w-4 h-4 mr-1" />
                          Jóváhagyás
                        </Button>
                        <Button size="sm" variant="destructive" onClick={() => handleRejectUser(user.id)}>
                          <XCircle className="w-4 h-4 mr-1" />
                          Elutasítás
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      {/* Pending Leave Requests */}
      {pendingLeaveRequests.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5" />
              Jóváhagyásra váró szabadságkérelmek ({pendingLeaveRequests.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Név</TableHead>
                  <TableHead>Beosztás</TableHead>
                  <TableHead>Szabadság típusa</TableHead>
                  <TableHead>Kezdete</TableHead>
                  <TableHead>Vége</TableHead>
                  <TableHead>Napok</TableHead>
                  <TableHead>Indoklás</TableHead>
                  <TableHead>Kérelem dátuma</TableHead>
                  <TableHead>Műveletek</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {pendingLeaveRequests.map((request) => (
                  <TableRow key={request.id}>
                    <TableCell className="font-medium">{request.requestedBy}</TableCell>
                    <TableCell>{request.rank}</TableCell>
                    <TableCell className="capitalize">{request.leaveType}</TableCell>
                    <TableCell>{request.startDate}</TableCell>
                    <TableCell>{request.endDate}</TableCell>
                    <TableCell>{calculateDays(request.startDate, request.endDate)}</TableCell>
                    <TableCell className="max-w-xs truncate">{request.reason}</TableCell>
                    <TableCell>{new Date(request.requestedAt).toLocaleDateString()}</TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          onClick={() => handleApproveLeaveRequest(request.id)}
                          className="bg-green-600 hover:bg-green-700"
                        >
                          <CheckCircle className="w-4 h-4 mr-1" />
                          Jóváhagyás
                        </Button>
                        <Button size="sm" variant="destructive" onClick={() => openRejectDialog(request.id)}>
                          <XCircle className="w-4 h-4 mr-1" />
                          Elutasítás
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      {/* No pending items message */}
      {pendingUsers.length === 0 && pendingLeaveRequests.length === 0 && (
        <Card>
          <CardContent className="text-center py-8">
            <Clock className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium mb-2">Nincsenek jóváhagyásra váró elemek</h3>
            <p className="text-muted-foreground">Minden regisztráció és szabadságkérelem fel van dolgozva.</p>
          </CardContent>
        </Card>
      )}

      {/* Rejection Dialog */}
      <Dialog open={isRejectDialogOpen} onOpenChange={setIsRejectDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Szabadságkérelem elutasítása</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="rejection-reason">Elutasítás oka</Label>
              <Textarea
                id="rejection-reason"
                value={rejectionReason}
                onChange={(e) => setRejectionReason(e.target.value)}
                placeholder="Kérem, adja meg az elutasítás okát..."
                rows={4}
                required
              />
            </div>
            <div className="flex gap-2">
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setIsRejectDialogOpen(false)
                  setRejectionReason("")
                  setSelectedRequestId(null)
                }}
                className="flex-1"
              >
                Mégse
              </Button>
              <Button
                type="button"
                variant="destructive"
                onClick={handleRejectLeaveRequest}
                disabled={!rejectionReason.trim()}
                className="flex-1"
              >
                Elutasítás
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
