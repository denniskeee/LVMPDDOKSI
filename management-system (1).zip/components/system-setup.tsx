"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Shield, CheckCircle } from "lucide-react"

interface SystemSetupProps {
  onSetupComplete: () => void
}

export function SystemSetup({ onSetupComplete }: SystemSetupProps) {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
    rank: "",
    badgeNumber: "",
  })
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")

  const ranks = [
    "Cadet",
    "Officer",
    "Senior Officer",
    "Corporal",
    "Sergeant",
    "Lieutenant",
    "Captain",
    "Major",
    "Colonel",
    "Deputy Chief",
    "Chief",
    "Sheriff",
  ]

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setIsLoading(true)

    // Validation
    if (formData.password !== formData.confirmPassword) {
      setError("A jelszavak nem egyeznek")
      setIsLoading(false)
      return
    }

    if (formData.password.length < 6) {
      setError("A jelszónak legalább 6 karakter hosszúnak kell lennie")
      setIsLoading(false)
      return
    }

    try {
      // Create admin user
      const adminUser = {
        id: 1,
        name: formData.name,
        email: formData.email,
        password: formData.password, // In production, this should be hashed
        rank: formData.rank,
        badgeNumber: formData.badgeNumber,
        isAdmin: true,
        approved: true,
        joinedDate: new Date().toLocaleDateString(),
        penaltyPoints: 0,
        isLeader: true,
      }

      // Save to localStorage
      localStorage.setItem("users", JSON.stringify([adminUser]))
      localStorage.setItem("currentUser", JSON.stringify(adminUser))
      localStorage.setItem("systemSetup", "true")

      // Initialize empty arrays for other data
      localStorage.setItem("announcements", JSON.stringify([]))
      localStorage.setItem("leaveRequests", JSON.stringify([]))
      localStorage.setItem("reports", JSON.stringify([]))
      localStorage.setItem("vehicles", JSON.stringify([]))
      localStorage.setItem("seizedCars", JSON.stringify([]))
      localStorage.setItem("weaponReports", JSON.stringify([]))
      localStorage.setItem("subDepartments", JSON.stringify([]))
      localStorage.setItem("subDepartmentAssignments", JSON.stringify([]))

      setTimeout(() => {
        onSetupComplete()
      }, 1000)
    } catch (error) {
      setError("Hiba történt a rendszer beállítása során")
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800 p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="mx-auto w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center mb-4">
            <Shield className="w-6 h-6 text-white" />
          </div>
          <CardTitle className="text-2xl">Rendszer Beállítás</CardTitle>
          <p className="text-muted-foreground">Hozza létre az első admin fiókot a rendszer inicializálásához</p>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Teljes név</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData((prev) => ({ ...prev, name: e.target.value }))}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">Email cím</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData((prev) => ({ ...prev, email: e.target.value }))}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="rank">Beosztás</Label>
              <Select
                value={formData.rank}
                onValueChange={(value) => setFormData((prev) => ({ ...prev, rank: value }))}
                required
              >
                <SelectTrigger>
                  <SelectValue placeholder="Válassza ki a beosztását" />
                </SelectTrigger>
                <SelectContent>
                  {ranks.map((rank) => (
                    <SelectItem key={rank} value={rank}>
                      {rank}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="badgeNumber">Jelvényszám</Label>
              <Input
                id="badgeNumber"
                value={formData.badgeNumber}
                onChange={(e) => setFormData((prev) => ({ ...prev, badgeNumber: e.target.value }))}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">Jelszó</Label>
              <Input
                id="password"
                type="password"
                value={formData.password}
                onChange={(e) => setFormData((prev) => ({ ...prev, password: e.target.value }))}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="confirmPassword">Jelszó megerősítése</Label>
              <Input
                id="confirmPassword"
                type="password"
                value={formData.confirmPassword}
                onChange={(e) => setFormData((prev) => ({ ...prev, confirmPassword: e.target.value }))}
                required
              />
            </div>

            {error && <div className="text-red-600 text-sm text-center">{error}</div>}

            <Button type="submit" className="w-full" disabled={isLoading}>
              {isLoading ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                  Rendszer beállítása...
                </>
              ) : (
                <>
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Rendszer beállítása
                </>
              )}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
