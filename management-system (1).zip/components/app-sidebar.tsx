"use client"

import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
} from "@/components/ui/sidebar"
import { Badge } from "@/components/ui/badge"
import {
  Home,
  Users,
  FileText,
  Calendar,
  Car,
  Shield,
  Gavel,
  Settings,
  User,
  Truck,
  ClipboardList,
  Inbox,
} from "lucide-react"

interface AppSidebarProps {
  user: any
  currentPage: string
  onPageChange: (page: string) => void
}

export function AppSidebar({ user, currentPage, onPageChange }: AppSidebarProps) {
  const getRankLevel = (rank: string): number => {
    const rankLevels: { [key: string]: number } = {
      Cadet: 1,
      Officer: 2,
      "Senior Officer": 3,
      Corporal: 4,
      Sergeant: 5,
      Lieutenant: 6,
      Captain: 7,
      Major: 8,
      Colonel: 9,
      "Deputy Chief": 10,
      Chief: 11,
      Sheriff: 12,
    }
    return rankLevels[rank] || 1
  }

  const canAccess = (requiredLevel: number): boolean => {
    return getRankLevel(user.rank) >= requiredLevel
  }

  const mainMenuItems = [
    {
      title: "Főoldal",
      url: "home",
      icon: Home,
      requiredLevel: 1,
    },
    {
      title: "Személyzet",
      url: "docs",
      icon: Users,
      requiredLevel: 1,
    },
    {
      title: "Jelentések",
      url: "reports",
      icon: FileText,
      requiredLevel: 1,
    },
  ]

  const requestItems = [
    {
      title: "Szabadság kérelem",
      url: "leave-requests",
      icon: Calendar,
      requiredLevel: 1,
    },
    {
      title: "Jármű igénylés",
      url: "vehicle-requests",
      icon: Truck,
      requiredLevel: 1,
    },
    {
      title: "UPR igénylés",
      url: "upr-requests",
      icon: ClipboardList,
      requiredLevel: 1,
    },
  ]

  const managementItems = [
    {
      title: "Járművek",
      url: "vehicles",
      icon: Car,
      requiredLevel: 1,
    },
    {
      title: "Lefoglalt járművek",
      url: "seized-cars",
      icon: Shield,
      requiredLevel: 6, // Lieutenant+
    },
    {
      title: "Fegyver bejelentés",
      url: "weapon-reports",
      icon: Gavel,
      requiredLevel: 5, // Sergeant+
    },
  ]

  const adminItems = [
    {
      title: "Igénylések",
      url: "incoming-requests",
      icon: Inbox,
      requiredLevel: 1,
      adminOnly: true,
    },
    {
      title: "Felhasználók",
      url: "user-management",
      icon: Settings,
      requiredLevel: 1,
      adminOnly: true,
    },
  ]

  return (
    <Sidebar>
      <SidebarHeader className="p-4">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
            <Shield className="w-4 h-4 text-white" />
          </div>
          <div>
            <h2 className="font-semibold text-sm">Rendőrség</h2>
            <p className="text-xs text-muted-foreground">Irányítási Rendszer</p>
          </div>
        </div>
      </SidebarHeader>

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Fő menü</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {mainMenuItems.map((item) => {
                if (!canAccess(item.requiredLevel)) return null

                return (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton onClick={() => onPageChange(item.url)} isActive={currentPage === item.url}>
                      <item.icon className="w-4 h-4" />
                      <span>{item.title}</span>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                )
              })}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          <SidebarGroupLabel>Igénylések</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {requestItems.map((item) => {
                if (!canAccess(item.requiredLevel)) return null

                return (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton onClick={() => onPageChange(item.url)} isActive={currentPage === item.url}>
                      <item.icon className="w-4 h-4" />
                      <span>{item.title}</span>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                )
              })}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          <SidebarGroupLabel>Kezelés</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {managementItems.map((item) => {
                if (!canAccess(item.requiredLevel)) return null

                return (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton onClick={() => onPageChange(item.url)} isActive={currentPage === item.url}>
                      <item.icon className="w-4 h-4" />
                      <span>{item.title}</span>
                      {item.requiredLevel > 1 && (
                        <Badge variant="secondary" className="ml-auto text-xs">
                          {item.requiredLevel === 6 ? "Lt+" : item.requiredLevel === 5 ? "Sgt+" : ""}
                        </Badge>
                      )}
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                )
              })}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {user.isAdmin && (
          <SidebarGroup>
            <SidebarGroupLabel>Admin</SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                {adminItems.map((item) => (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton onClick={() => onPageChange(item.url)} isActive={currentPage === item.url}>
                      <item.icon className="w-4 h-4" />
                      <span>{item.title}</span>
                      <Badge variant="destructive" className="ml-auto text-xs">
                        Admin
                      </Badge>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}
      </SidebarContent>

      <SidebarFooter className="p-4">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-muted rounded-full flex items-center justify-center">
            <User className="w-4 h-4" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium truncate">{user.name}</p>
            <p className="text-xs text-muted-foreground">{user.rank}</p>
          </div>
          {user.isAdmin && (
            <Badge variant="destructive" className="text-xs">
              Admin
            </Badge>
          )}
        </div>
      </SidebarFooter>
    </Sidebar>
  )
}
