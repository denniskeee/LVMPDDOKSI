"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Shield, UserPlus } from "lucide-react"

interface RegistrationFormProps {
  onRegistrationComplete: () => void
  onShowLogin: () => void
}

export function RegistrationForm({ onRegistrationComplete, onShowLogin }: RegistrationFormProps) {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
    rank: "",
    badgeNumber: "",
  })
  const [error, setError] = useState("")
  const [isLoading, setIsLoading] = useState(false)

  const ranks = [
    "Cadet",
    "Officer",
    "Senior Officer",
    "Corporal",
    "Sergeant",
    "Lieutenant",
    "Captain",
    "Major",
    "Colonel",
    "Deputy Chief",
    "Chief",
    "Sheriff",
  ]

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setIsLoading(true)

    // Validation
    if (formData.password !== formData.confirmPassword) {
      setError("A jelszavak nem egyeznek")
      setIsLoading(false)
      return
    }

    if (formData.password.length < 6) {
      setError("A jelszónak legalább 6 karakter hosszúnak kell lennie")
      setIsLoading(false)
      return
    }

    try {
      const users = JSON.parse(localStorage.getItem("users") || "[]")

      // Check if email already exists
      if (users.some((u: any) => u.email === formData.email)) {
        setError("Ez az email cím már regisztrálva van")
        setIsLoading(false)
        return
      }

      // Check if badge number already exists
      if (users.some((u: any) => u.badgeNumber === formData.badgeNumber)) {
        setError("Ez a jelvényszám már használatban van")
        setIsLoading(false)
        return
      }

      const newUser = {
        id: Date.now(),
        name: formData.name,
        email: formData.email,
        password: formData.password,
        rank: formData.rank,
        badgeNumber: formData.badgeNumber,
        isAdmin: false,
        approved: false,
        joinedDate: new Date().toLocaleDateString(),
        penaltyPoints: 0,
        isLeader: false,
      }

      const updatedUsers = [...users, newUser]
      localStorage.setItem("users", JSON.stringify(updatedUsers))

      setTimeout(() => {
        onRegistrationComplete()
      }, 1000)
    } catch (error) {
      setError("Hiba történt a regisztráció során")
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800 p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="mx-auto w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center mb-4">
            <Shield className="w-6 h-6 text-white" />
          </div>
          <CardTitle className="text-2xl">Regisztráció</CardTitle>
          <p className="text-muted-foreground">Hozzon létre új fiókot a rendszerben</p>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Teljes név</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData((prev) => ({ ...prev, name: e.target.value }))}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">Email cím</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData((prev) => ({ ...prev, email: e.target.value }))}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="rank">Beosztás</Label>
              <Select
                value={formData.rank}
                onValueChange={(value) => setFormData((prev) => ({ ...prev, rank: value }))}
                required
              >
                <SelectTrigger>
                  <SelectValue placeholder="Válassza ki a beosztását" />
                </SelectTrigger>
                <SelectContent>
                  {ranks.map((rank) => (
                    <SelectItem key={rank} value={rank}>
                      {rank}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="badgeNumber">Jelvényszám</Label>
              <Input
                id="badgeNumber"
                value={formData.badgeNumber}
                onChange={(e) => setFormData((prev) => ({ ...prev, badgeNumber: e.target.value }))}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">Jelszó</Label>
              <Input
                id="password"
                type="password"
                value={formData.password}
                onChange={(e) => setFormData((prev) => ({ ...prev, password: e.target.value }))}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="confirmPassword">Jelszó megerősítése</Label>
              <Input
                id="confirmPassword"
                type="password"
                value={formData.confirmPassword}
                onChange={(e) => setFormData((prev) => ({ ...prev, confirmPassword: e.target.value }))}
                required
              />
            </div>

            {error && <div className="text-red-600 text-sm text-center">{error}</div>}

            <Button type="submit" className="w-full" disabled={isLoading}>
              {isLoading ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                  Regisztráció...
                </>
              ) : (
                <>
                  <UserPlus className="w-4 h-4 mr-2" />
                  Regisztráció
                </>
              )}
            </Button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-sm text-muted-foreground">
              Már van fiókja?{" "}
              <button onClick={onShowLogin} className="text-blue-600 hover:underline font-medium">
                Bejelentkezés
              </button>
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
