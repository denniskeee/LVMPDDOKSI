"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Megaphone } from "lucide-react"

interface AnnouncementFormProps {
  user: any
  onAnnouncementAdded: (announcement: any) => void
  onClose: () => void
}

export function AnnouncementForm({ user, onAnnouncementAdded, onClose }: AnnouncementFormProps) {
  const [formData, setFormData] = useState({
    title: "",
    content: "",
    priority: "",
    effectType: "none",
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    const newAnnouncement = {
      id: Date.now(),
      title: formData.title,
      content: formData.content,
      priority: formData.priority,
      effectType: formData.effectType,
      author: user.name,
      authorRank: user.rank,
      createdAt: new Date().toISOString(),
    }

    // Save to localStorage
    const announcements = JSON.parse(localStorage.getItem("announcements") || "[]")
    const updatedAnnouncements = [newAnnouncement, ...announcements]
    localStorage.setItem("announcements", JSON.stringify(updatedAnnouncements))

    onAnnouncementAdded(newAnnouncement)
  }

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Megaphone className="w-5 h-5" />
            Új közlemény létrehozása
          </DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="title">Cím</Label>
            <Input
              id="title"
              value={formData.title}
              onChange={(e) => setFormData((prev) => ({ ...prev, title: e.target.value }))}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="content">Tartalom</Label>
            <Textarea
              id="content"
              value={formData.content}
              onChange={(e) => setFormData((prev) => ({ ...prev, content: e.target.value }))}
              rows={4}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="priority">Prioritás</Label>
            <Input
              id="priority"
              value={formData.priority}
              onChange={(e) => setFormData((prev) => ({ ...prev, priority: e.target.value }))}
              placeholder="pl. Sürgős, Fontos, Normál..."
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="effectType">Vizuális effekt</Label>
            <Select
              value={formData.effectType}
              onValueChange={(value) => setFormData((prev) => ({ ...prev, effectType: value }))}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">Nincs effekt</SelectItem>
                <SelectItem value="glow">Világítás effekt</SelectItem>
                <SelectItem value="shake">Rázás effekt</SelectItem>
                <SelectItem value="pulse">Pulzálás effekt</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex gap-2">
            <Button type="button" variant="outline" onClick={onClose} className="flex-1 bg-transparent">
              Mégse
            </Button>
            <Button type="submit" className="flex-1">
              Közzététel
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}
