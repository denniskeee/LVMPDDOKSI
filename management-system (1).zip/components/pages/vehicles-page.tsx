"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Plus, Edit, Trash2, Car } from "lucide-react"

export function VehiclesPage() {
  const [vehicles, setVehicles] = useState<any[]>([])
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [editingVehicle, setEditingVehicle] = useState<any>(null)
  const [formData, setFormData] = useState({
    make: "",
    model: "",
    year: "",
    licensePlate: "",
    vin: "",
    status: "active",
    assignedTo: "",
  })

  useEffect(() => {
    const savedVehicles = JSON.parse(localStorage.getItem("vehicles") || "[]")
    setVehicles(savedVehicles)
  }, [])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (editingVehicle) {
      const updatedVehicles = vehicles.map((vehicle) =>
        vehicle.id === editingVehicle.id ? { ...vehicle, ...formData } : vehicle,
      )
      setVehicles(updatedVehicles)
      localStorage.setItem("vehicles", JSON.stringify(updatedVehicles))
    } else {
      const newVehicle = {
        ...formData,
        id: Date.now(),
        addedAt: new Date().toISOString(),
      }
      const updatedVehicles = [...vehicles, newVehicle]
      setVehicles(updatedVehicles)
      localStorage.setItem("vehicles", JSON.stringify(updatedVehicles))
    }

    resetForm()
  }

  const resetForm = () => {
    setFormData({
      make: "",
      model: "",
      year: "",
      licensePlate: "",
      vin: "",
      status: "active",
      assignedTo: "",
    })
    setEditingVehicle(null)
    setIsAddDialogOpen(false)
  }

  const handleEdit = (vehicle: any) => {
    setEditingVehicle(vehicle)
    setFormData({
      make: vehicle.make,
      model: vehicle.model,
      year: vehicle.year,
      licensePlate: vehicle.licensePlate,
      vin: vehicle.vin,
      status: vehicle.status,
      assignedTo: vehicle.assignedTo || "",
    })
    setIsAddDialogOpen(true)
  }

  const handleDelete = (id: number) => {
    const updatedVehicles = vehicles.filter((vehicle) => vehicle.id !== id)
    setVehicles(updatedVehicles)
    localStorage.setItem("vehicles", JSON.stringify(updatedVehicles))
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "default"
      case "maintenance":
        return "secondary"
      case "out-of-service":
        return "destructive"
      default:
        return "secondary"
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Járművek Listája</h1>
          <p className="text-muted-foreground">Itt tudjátok módosítani a járművek listáját</p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => setEditingVehicle(null)}>
              <Plus className="w-4 h-4 mr-2" />
              Jármű hozzáadása
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingVehicle ? "Jármű szerkesztése" : "Új jármű hozzáadása"}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="make">Gyártó</Label>
                  <Input
                    id="make"
                    value={formData.make}
                    onChange={(e) => setFormData((prev) => ({ ...prev, make: e.target.value }))}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="model">Típus</Label>
                  <Input
                    id="model"
                    value={formData.model}
                    onChange={(e) => setFormData((prev) => ({ ...prev, model: e.target.value }))}
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="year">Évjárat</Label>
                  <Input
                    id="year"
                    value={formData.year}
                    onChange={(e) => setFormData((prev) => ({ ...prev, year: e.target.value }))}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="licensePlate">Rendszám</Label>
                  <Input
                    id="licensePlate"
                    value={formData.licensePlate}
                    onChange={(e) => setFormData((prev) => ({ ...prev, licensePlate: e.target.value }))}
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="vin">Alvázszám(ID)</Label>
                <Input
                  id="vin"
                  value={formData.vin}
                  onChange={(e) => setFormData((prev) => ({ ...prev, vin: e.target.value }))}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="status">Státusz</Label>
                <Select
                  value={formData.status}
                  onValueChange={(value) => setFormData((prev) => ({ ...prev, status: value }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">Kiadva</SelectItem>
                    <SelectItem value="maintenance">Alosztály</SelectItem>
                    <SelectItem value="out-of-service">Használaton kívül</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="assignedTo">Hozzárendelve</Label>
                <Input
                  id="assignedTo"
                  value={formData.assignedTo}
                  onChange={(e) => setFormData((prev) => ({ ...prev, assignedTo: e.target.value }))}
                  placeholder="Tiszt neve vagy egység"
                />
              </div>

              <div className="flex gap-2">
                <Button type="button" variant="outline" onClick={resetForm} className="flex-1 bg-transparent">
                  Mégse
                </Button>
                <Button type="submit" className="flex-1">
                  {editingVehicle ? "Frissítés" : "Hozzáadás"}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Összes Jármű</CardTitle>
            <Car className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{vehicles.length}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Kiadva</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {vehicles.filter((v) => v.status === "active").length}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Alosztály</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">
              {vehicles.filter((v) => v.status === "maintenance").length}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Használaton kívül</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">
              {vehicles.filter((v) => v.status === "out-of-service").length}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Járműpark</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Jármű</TableHead>
                <TableHead>Rendszám</TableHead>
                <TableHead>Alvázszám(ID)</TableHead>
                <TableHead>Státusz</TableHead>
                <TableHead>Hozzárendelve</TableHead>
                <TableHead>Műveletek</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {vehicles.map((vehicle) => (
                <TableRow key={vehicle.id}>
                  <TableCell className="font-medium">
                    {vehicle.year} {vehicle.make} {vehicle.model}
                  </TableCell>
                  <TableCell>{vehicle.licensePlate}</TableCell>
                  <TableCell className="font-mono text-sm">{vehicle.vin}</TableCell>
                  <TableCell>
                    <Badge variant={getStatusColor(vehicle.status)}>
                      {vehicle.status === "active"
                        ? "Kiadva"
                        : vehicle.status === "maintenance"
                          ? "Alosztály"
                          : "Használaton kívül"}
                    </Badge>
                  </TableCell>
                  <TableCell>{vehicle.assignedTo || "Nincs hozzárendelve"}</TableCell>
                  <TableCell>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm" onClick={() => handleEdit(vehicle)}>
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button variant="outline" size="sm" onClick={() => handleDelete(vehicle.id)}>
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
