"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { FileText, Trash2 } from "lucide-react"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"

interface UprRequestPageProps {
  user: any
}

export function UprRequestPage({ user }: UprRequestPageProps) {
  const [requests, setRequests] = useState<any[]>([])
  const [formData, setFormData] = useState({
    rank: "",
    weaponType: "",
    serialNumber: "",
    weaponSkin: "",
  })
  const [showDeleteConfirmDialog, setShowDeleteConfirmDialog] = useState(false)
  const [requestToDeleteId, setRequestToDeleteId] = useState<number | null>(null)

  useEffect(() => {
    const savedRequests = JSON.parse(localStorage.getItem("uprRequests") || "[]")
    setRequests(savedRequests)
  }, [])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    const newRequest = {
      ...formData,
      id: Date.now(),
      requestedBy: user.name,
      userRank: user.rank,
      requestedAt: new Date().toISOString(),
      status: "Jóváhagyás függőben",
      rejectionReason: undefined,
    }

    const updatedRequests = [newRequest, ...requests]
    setRequests(updatedRequests)
    localStorage.setItem("uprRequests", JSON.stringify(updatedRequests))

    setFormData({
      rank: "",
      weaponType: "",
      serialNumber: "",
      weaponSkin: "",
    })
  }

  const handleDeleteClick = (id: number) => {
    setRequestToDeleteId(id)
    setShowDeleteConfirmDialog(true)
  }

  const confirmDelete = () => {
    if (requestToDeleteId !== null) {
      const updatedRequests = requests.filter((request) => request.id !== requestToDeleteId)
      setRequests(updatedRequests)
      localStorage.setItem("uprRequests", JSON.stringify(updatedRequests))
      setRequestToDeleteId(null)
      setShowDeleteConfirmDialog(false)
    }
  }

  const cancelDelete = () => {
    setRequestToDeleteId(null)
    setShowDeleteConfirmDialog(false)
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Elfogadva":
        return "default"
      case "Elutasítva":
        return "destructive"
      case "Jóváhagyás függőben":
        return "secondary"
      case "Feldolgozás alatt":
        return "outline"
      default:
        return "secondary"
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">UPR Igénylés</h1>
        <p className="text-muted-foreground">Általános igénylések és kérelmek beküldése</p>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Új UPR igénylés</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="rank">Rendfokozat</Label>
                <Input
                  id="rank"
                  value={formData.rank}
                  onChange={(e) => setFormData((prev) => ({ ...prev, rank: e.target.value }))}
                  placeholder="Adja meg a rendfokozatot"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="weaponType">Igényelt fegyver típusa</Label>
                <Input
                  id="weaponType"
                  value={formData.weaponType}
                  onChange={(e) => setFormData((prev) => ({ ...prev, weaponType: e.target.value }))}
                  placeholder="Adja meg a fegyver típusát"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="serialNumber">Add meg a sorozatszámot</Label>
                <Input
                  id="serialNumber"
                  value={formData.serialNumber}
                  onChange={(e) => setFormData((prev) => ({ ...prev, serialNumber: e.target.value }))}
                  placeholder="Add meg a sorozatszámot"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="weaponSkin">Fegyver skin (ha van)</Label>
                <Input
                  id="weaponSkin"
                  value={formData.weaponSkin}
                  onChange={(e) => setFormData((prev) => ({ ...prev, weaponSkin: e.target.value }))}
                  placeholder="Skin neve (opcionális)"
                />
              </div>

              <Button type="submit" className="w-full">
                <FileText className="w-4 h-4 mr-2" />
                UPR Igénylés Beküldése
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Legutóbbi igényléseim</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4 max-h-96 overflow-y-auto">
              {requests.filter((req) => req.requestedBy === user.name).length === 0 ? (
                <p className="text-muted-foreground text-center py-4">Még nem nyújtottak be UPR igénylést</p>
              ) : (
                requests
                  .filter((req) => req.requestedBy === user.name)
                  .slice(0, 5)
                  .map((request) => (
                    <div key={request.id} className="border rounded-lg p-3">
                      <div className="flex justify-between items-start mb-2">
                        <h4 className="font-medium">{request.weaponType}</h4>
                        <div className="flex gap-2">
                          <Badge variant="outline">Normál</Badge>
                          <Badge variant={getStatusColor(request.status)}>{request.status}</Badge>
                        </div>
                      </div>
                      <p className="text-sm text-muted-foreground mb-1">Rendfokozat: {request.rank}</p>
                      <p className="text-sm">Sorozatszám: {request.serialNumber}</p>
                      {request.weaponSkin && <p className="text-sm">Skin: {request.weaponSkin}</p>}
                      {request.expectedDate && (
                        <p className="text-sm text-muted-foreground">Elvárható teljesítés: {request.expectedDate}</p>
                      )}
                      {request.status === "Elutasítva" && request.rejectionReason && (
                        <div className="mt-2 p-2 bg-red-50 dark:bg-red-950 border border-red-200 dark:border-red-800 rounded-md text-sm text-red-700 dark:text-red-300">
                          <p className="font-semibold">Elutasítás oka:</p>
                          <p>{request.rejectionReason}</p>
                        </div>
                      )}
                      <p className="text-xs text-muted-foreground mt-2">
                        Kelt: {new Date(request.requestedAt).toLocaleDateString()}
                      </p>
                    </div>
                  ))
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Minden UPR Igénylés</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Név</TableHead>
                <TableHead>Beosztás</TableHead>
                <TableHead>Rendfokozat</TableHead>
                <TableHead>Fegyver típusa</TableHead>
                <TableHead>Sorozatszám</TableHead>
                <TableHead>Skin</TableHead>
                <TableHead>Sürgősség</TableHead>
                <TableHead>Elvárható dátum</TableHead>
                <TableHead>Státusz</TableHead>
                <TableHead>Kelt</TableHead>
                {user.isAdmin && <TableHead>Műveletek</TableHead>}
              </TableRow>
            </TableHeader>
            <TableBody>
              {requests.map((request) => (
                <TableRow key={request.id}>
                  <TableCell className="font-medium">{request.requestedBy}</TableCell>
                  <TableCell>{request.rank}</TableCell>
                  <TableCell>{request.userRank}</TableCell>
                  <TableCell>{request.weaponType}</TableCell>
                  <TableCell>{request.serialNumber}</TableCell>
                  <TableCell>{request.weaponSkin || "Nincs"}</TableCell>
                  <TableCell>
                    <Badge variant="outline">Normál</Badge>
                  </TableCell>
                  <TableCell>{request.expectedDate || "N/A"}</TableCell>
                  <TableCell>
                    <Badge variant={getStatusColor(request.status)}>{request.status}</Badge>
                  </TableCell>
                  <TableCell>{new Date(request.requestedAt).toLocaleDateString()}</TableCell>
                  {user.isAdmin && (
                    <TableCell>
                      <Button variant="outline" size="sm" onClick={() => handleDeleteClick(request.id)} title="Törlés">
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </TableCell>
                  )}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <AlertDialog open={showDeleteConfirmDialog} onOpenChange={setShowDeleteConfirmDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Biztosan törölni szeretné ezt az UPR igénylést?</AlertDialogTitle>
            <AlertDialogDescription>
              Ez a művelet nem vonható vissza. Ez véglegesen törli az UPR igénylést.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={cancelDelete}>Mégse</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-destructive hover:bg-destructive/90">
              Törlés
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
