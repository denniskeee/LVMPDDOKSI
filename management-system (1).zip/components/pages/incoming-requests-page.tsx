"use client"
import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { CheckCircle, XCircle, Calendar, Truck, ClipboardList, Clock, Inbox } from "lucide-react"

interface IncomingRequestsPageProps {
  user: any
}

export function IncomingRequestsPage({ user }: IncomingRequestsPageProps) {
  const [leaveRequests, setLeaveRequests] = useState<any[]>([])
  const [vehicleRequests, setVehicleRequests] = useState<any[]>([])
  const [uprRequests, setUprRequests] = useState<any[]>([])
  const [availableVehicles, setAvailableVehicles] = useState<any[]>([])

  const [showRejectDialog, setShowRejectDialog] = useState(false)
  const [selectedRequest, setSelectedRequest] = useState<any>(null)
  const [requestType, setRequestType] = useState<string>("")
  const [rejectionReason, setRejectionReason] = useState("")

  useEffect(() => {
    const savedLeaveRequests = JSON.parse(localStorage.getItem("leaveRequests") || "[]")
    setLeaveRequests(savedLeaveRequests)

    const savedVehicleRequests = JSON.parse(localStorage.getItem("vehicleRequests") || "[]")
    setVehicleRequests(savedVehicleRequests)

    const savedUprRequests = JSON.parse(localStorage.getItem("uprRequests") || "[]")
    setUprRequests(savedUprRequests)

    const savedVehicles = JSON.parse(localStorage.getItem("vehicles") || "[]")
    setAvailableVehicles(savedVehicles)
  }, [])

  const calculateDays = (start: string, end: string) => {
    if (!start || !end) return 0
    const startDate = new Date(start)
    const endDate = new Date(end)
    const diffTime = Math.abs(endDate.getTime() - startDate.getTime())
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1
    return diffDays
  }

  const getVehicleInfo = (vehicleId: string) => {
    const vehicle = availableVehicles.find((v) => v.id.toString() === vehicleId)
    return vehicle ? `${vehicle.year} ${vehicle.make} ${vehicle.model} - ${vehicle.licensePlate}` : vehicleId
  }

  const getUrgencyLabel = (urgency: string) => {
    const urgencyLevels: { [key: string]: string } = {
      low: "Alacsony",
      normal: "Normál",
      high: "Sürgős",
      critical: "Kritikus",
    }
    return urgencyLevels[urgency] || "Normál"
  }

  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case "critical":
        return "destructive"
      case "high":
        return "secondary"
      case "normal":
        return "outline"
      case "low":
        return "default"
      default:
        return "outline"
    }
  }

  const handleApproveLeaveRequest = (requestId: number) => {
    const updatedRequests = leaveRequests.map((req) =>
      req.id === requestId ? { ...req, status: "Elfogadva", approvedAt: new Date().toISOString() } : req,
    )
    setLeaveRequests(updatedRequests)
    localStorage.setItem("leaveRequests", JSON.stringify(updatedRequests))
  }

  const handleApproveVehicleRequest = (requestId: number) => {
    const updatedRequests = vehicleRequests.map((req) =>
      req.id === requestId ? { ...req, status: "Elfogadva", approvedAt: new Date().toISOString() } : req,
    )
    setVehicleRequests(updatedRequests)
    localStorage.setItem("vehicleRequests", JSON.stringify(updatedRequests))
  }

  const handleApproveUprRequest = (requestId: number) => {
    const updatedRequests = uprRequests.map((req) =>
      req.id === requestId ? { ...req, status: "Elfogadva", approvedAt: new Date().toISOString() } : req,
    )
    setUprRequests(updatedRequests)
    localStorage.setItem("uprRequests", JSON.stringify(updatedRequests))
  }

  const handleRejectClick = (request: any, type: string) => {
    setSelectedRequest(request)
    setRequestType(type)
    setShowRejectDialog(true)
  }

  const handleRejectConfirm = () => {
    if (selectedRequest && rejectionReason.trim()) {
      const rejectedRequest = {
        ...selectedRequest,
        status: "Elutasítva",
        rejectionReason: rejectionReason.trim(),
        rejectedAt: new Date().toISOString(),
      }

      if (requestType === "leave") {
        const updatedRequests = leaveRequests.map((req) => (req.id === selectedRequest.id ? rejectedRequest : req))
        setLeaveRequests(updatedRequests)
        localStorage.setItem("leaveRequests", JSON.stringify(updatedRequests))
      } else if (requestType === "vehicle") {
        const updatedRequests = vehicleRequests.map((req) => (req.id === selectedRequest.id ? rejectedRequest : req))
        setVehicleRequests(updatedRequests)
        localStorage.setItem("vehicleRequests", JSON.stringify(updatedRequests))
      } else if (requestType === "upr") {
        const updatedRequests = uprRequests.map((req) => (req.id === selectedRequest.id ? rejectedRequest : req))
        setUprRequests(updatedRequests)
        localStorage.setItem("uprRequests", JSON.stringify(updatedRequests))
      }

      setRejectionReason("")
      setSelectedRequest(null)
      setRequestType("")
      setShowRejectDialog(false)
    }
  }

  const pendingLeaveRequests = leaveRequests.filter((req) => req.status === "Jóváhagyás függőben")
  const pendingVehicleRequests = vehicleRequests.filter((req) => req.status === "Jóváhagyás függőben")
  const pendingUprRequests = uprRequests.filter((req) => req.status === "Jóváhagyás függőben")

  const totalPendingRequests = pendingLeaveRequests.length + pendingVehicleRequests.length + pendingUprRequests.length

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Beérkezett Igénylések</h1>
        <p className="text-muted-foreground">Összes függőben lévő igénylés kezelése</p>
      </div>

      {/* Statistics Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Összes függőben</CardTitle>
            <Inbox className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalPendingRequests}</div>
            <p className="text-xs text-muted-foreground">Jóváhagyásra vár</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Szabadság kérelmek</CardTitle>
            <Calendar className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{pendingLeaveRequests.length}</div>
            <p className="text-xs text-muted-foreground">Függőben lévő</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Jármű igénylések</CardTitle>
            <Truck className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{pendingVehicleRequests.length}</div>
            <p className="text-xs text-muted-foreground">Függőben lévő</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">UPR igénylések</CardTitle>
            <ClipboardList className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-600">{pendingUprRequests.length}</div>
            <p className="text-xs text-muted-foreground">Függőben lévő</p>
          </CardContent>
        </Card>
      </div>

      {totalPendingRequests === 0 ? (
        <Card>
          <CardContent className="text-center py-8">
            <Clock className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium mb-2">Nincsenek függőben lévő igénylések</h3>
            <p className="text-muted-foreground">Minden igénylés fel van dolgozva.</p>
          </CardContent>
        </Card>
      ) : (
        <Tabs defaultValue="leave" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="leave" className="flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              Szabadság ({pendingLeaveRequests.length})
            </TabsTrigger>
            <TabsTrigger value="vehicle" className="flex items-center gap-2">
              <Truck className="w-4 h-4" />
              Jármű ({pendingVehicleRequests.length})
            </TabsTrigger>
            <TabsTrigger value="upr" className="flex items-center gap-2">
              <ClipboardList className="w-4 h-4" />
              UPR ({pendingUprRequests.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="leave" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Szabadság kérelmek</CardTitle>
              </CardHeader>
              <CardContent>
                {pendingLeaveRequests.length === 0 ? (
                  <p className="text-muted-foreground text-center py-4">Nincsenek függőben lévő szabadság kérelmek.</p>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Név</TableHead>
                        <TableHead>Beosztás</TableHead>
                        <TableHead>Típus</TableHead>
                        <TableHead>Kezdete</TableHead>
                        <TableHead>Vége</TableHead>
                        <TableHead>Napok</TableHead>
                        <TableHead>Indoklás</TableHead>
                        <TableHead>Kérelem dátuma</TableHead>
                        <TableHead>Műveletek</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {pendingLeaveRequests.map((request) => (
                        <TableRow key={request.id}>
                          <TableCell className="font-medium">{request.requestedBy}</TableCell>
                          <TableCell>{request.rank}</TableCell>
                          <TableCell className="capitalize">{request.leaveType}</TableCell>
                          <TableCell>{request.startDate}</TableCell>
                          <TableCell>{request.endDate}</TableCell>
                          <TableCell>{calculateDays(request.startDate, request.endDate)}</TableCell>
                          <TableCell className="max-w-xs truncate">{request.reason}</TableCell>
                          <TableCell>{new Date(request.requestedAt).toLocaleDateString()}</TableCell>
                          <TableCell>
                            <div className="flex gap-2">
                              <Button
                                size="sm"
                                onClick={() => handleApproveLeaveRequest(request.id)}
                                className="bg-green-600 hover:bg-green-700"
                              >
                                <CheckCircle className="w-4 h-4 mr-1" />
                                Jóváhagyás
                              </Button>
                              <Button
                                size="sm"
                                variant="destructive"
                                onClick={() => handleRejectClick(request, "leave")}
                              >
                                <XCircle className="w-4 h-4 mr-1" />
                                Elutasítás
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="vehicle" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Jármű igénylések</CardTitle>
              </CardHeader>
              <CardContent>
                {pendingVehicleRequests.length === 0 ? (
                  <p className="text-muted-foreground text-center py-4">Nincsenek függőben lévő jármű igénylések.</p>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Név</TableHead>
                        <TableHead>Beosztás</TableHead>
                        <TableHead>Jármű</TableHead>
                        <TableHead>Dátum</TableHead>
                        <TableHead>Beosztás</TableHead>
                        <TableHead>Cél</TableHead>
                        <TableHead>Kérelem dátuma</TableHead>
                        <TableHead>Műveletek</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {pendingVehicleRequests.map((request) => (
                        <TableRow key={request.id}>
                          <TableCell className="font-medium">{request.requestedBy}</TableCell>
                          <TableCell>{request.rank}</TableCell>
                          <TableCell>{getVehicleInfo(request.selectedVehicle)}</TableCell>
                          <TableCell>{request.requestDate}</TableCell>
                          <TableCell>{request.assignment}</TableCell>
                          <TableCell className="max-w-xs truncate">{request.purpose}</TableCell>
                          <TableCell>{new Date(request.requestedAt).toLocaleDateString()}</TableCell>
                          <TableCell>
                            <div className="flex gap-2">
                              <Button
                                size="sm"
                                onClick={() => handleApproveVehicleRequest(request.id)}
                                className="bg-green-600 hover:bg-green-700"
                              >
                                <CheckCircle className="w-4 h-4 mr-1" />
                                Jóváhagyás
                              </Button>
                              <Button
                                size="sm"
                                variant="destructive"
                                onClick={() => handleRejectClick(request, "vehicle")}
                              >
                                <XCircle className="w-4 h-4 mr-1" />
                                Elutasítás
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="upr" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>UPR igénylések</CardTitle>
              </CardHeader>
              <CardContent>
                {pendingUprRequests.length === 0 ? (
                  <p className="text-muted-foreground text-center py-4">Nincsenek függőben lévő UPR igénylések.</p>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Név</TableHead>
                        <TableHead>Beosztás</TableHead>
                        <TableHead>Típus</TableHead>
                        <TableHead>Tárgy</TableHead>
                        <TableHead>Sürgősség</TableHead>
                        <TableHead>Elvárható dátum</TableHead>
                        <TableHead>Leírás</TableHead>
                        <TableHead>Kérelem dátuma</TableHead>
                        <TableHead>Műveletek</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {pendingUprRequests.map((request) => (
                        <TableRow key={request.id}>
                          <TableCell className="font-medium">{request.requestedBy}</TableCell>
                          <TableCell>{request.rank}</TableCell>
                          <TableCell>{request.requestType}</TableCell>
                          <TableCell className="max-w-xs truncate">{request.subject}</TableCell>
                          <TableCell>
                            <Badge variant={getUrgencyColor(request.urgency)}>{getUrgencyLabel(request.urgency)}</Badge>
                          </TableCell>
                          <TableCell>{request.expectedDate || "N/A"}</TableCell>
                          <TableCell className="max-w-xs truncate">{request.description}</TableCell>
                          <TableCell>{new Date(request.requestedAt).toLocaleDateString()}</TableCell>
                          <TableCell>
                            <div className="flex gap-2">
                              <Button
                                size="sm"
                                onClick={() => handleApproveUprRequest(request.id)}
                                className="bg-green-600 hover:bg-green-700"
                              >
                                <CheckCircle className="w-4 h-4 mr-1" />
                                Jóváhagyás
                              </Button>
                              <Button size="sm" variant="destructive" onClick={() => handleRejectClick(request, "upr")}>
                                <XCircle className="w-4 h-4 mr-1" />
                                Elutasítás
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      )}

      {/* Rejection Dialog */}
      <Dialog open={showRejectDialog} onOpenChange={setShowRejectDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Igénylés elutasítása</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="rejection-reason">Elutasítás oka</Label>
              <Textarea
                id="rejection-reason"
                value={rejectionReason}
                onChange={(e) => setRejectionReason(e.target.value)}
                placeholder="Kérem, adja meg az elutasítás okát..."
                rows={4}
                required
              />
            </div>
            <div className="flex gap-2">
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setShowRejectDialog(false)
                  setRejectionReason("")
                  setSelectedRequest(null)
                  setRequestType("")
                }}
                className="flex-1"
              >
                Mégse
              </Button>
              <Button
                type="button"
                variant="destructive"
                onClick={handleRejectConfirm}
                disabled={!rejectionReason.trim()}
                className="flex-1"
              >
                Elutasítás
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
