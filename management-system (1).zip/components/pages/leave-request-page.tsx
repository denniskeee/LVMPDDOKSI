"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Calendar, Clock, Trash2 } from "lucide-react"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"

interface LeaveRequestPageProps {
  user: any
}

export function LeaveRequestPage({ user }: LeaveRequestPageProps) {
  const [requests, setRequests] = useState<any[]>([])
  const [formData, setFormData] = useState({
    leaveType: "",
    startDate: "",
    endDate: "",
    reason: "",
  })
  const [showDeleteConfirmDialog, setShowDeleteConfirmDialog] = useState(false)
  const [requestToDeleteId, setRequestToDeleteId] = useState<number | null>(null)

  useEffect(() => {
    const savedRequests = JSON.parse(localStorage.getItem("leaveRequests") || "[]")
    setRequests(savedRequests)
  }, [])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    const newRequest = {
      ...formData,
      id: Date.now(),
      requestedBy: user.name,
      rank: user.rank,
      requestedAt: new Date().toISOString(),
      status: "Jóváhagyás függőben",
      rejectionReason: undefined,
    }

    const updatedRequests = [newRequest, ...requests]
    setRequests(updatedRequests)
    localStorage.setItem("leaveRequests", JSON.stringify(updatedRequests))

    setFormData({
      leaveType: "",
      startDate: "",
      endDate: "",
      reason: "",
    })
  }

  const calculateDays = (start: string, end: string) => {
    if (!start || !end) return 0
    const startDate = new Date(start)
    const endDate = new Date(end)
    const diffTime = Math.abs(endDate.getTime() - startDate.getTime())
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1
    return diffDays
  }

  const handleDeleteClick = (id: number) => {
    setRequestToDeleteId(id)
    setShowDeleteConfirmDialog(true)
  }

  const confirmDelete = () => {
    if (requestToDeleteId !== null) {
      const updatedRequests = requests.filter((request) => request.id !== requestToDeleteId)
      setRequests(updatedRequests)
      localStorage.setItem("leaveRequests", JSON.stringify(updatedRequests))
      setRequestToDeleteId(null)
      setShowDeleteConfirmDialog(false)
    }
  }

  const cancelDelete = () => {
    setRequestToDeleteId(null)
    setShowDeleteConfirmDialog(false)
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Elfogadva":
        return "default"
      case "Elutasítva":
        return "destructive"
      case "Jóváhagyás függőben":
        return "secondary"
      default:
        return "secondary"
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Szabadság kérelem</h1>
        <p className="text-muted-foreground">Szabadságkérelmek beküldése és állapotuk nyomonkövetése</p>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Szabadság kérelmezése</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="leaveType">Szabadság Típusa</Label>
                <Select
                  value={formData.leaveType}
                  onValueChange={(value) => setFormData((prev) => ({ ...prev, leaveType: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Válassza ki a szabadság típusát" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Nyaralás">Nyaralás</SelectItem>
                    <SelectItem value="Betegszabadság(Betegség)">Betegszabadság(Betegség)</SelectItem>
                    <SelectItem value="Családi Okok">Családi Okok</SelectItem>
                    <SelectItem value="Egyéb">Egyéb</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="startDate">Szabadság Kezdete</Label>
                  <Input
                    id="startDate"
                    type="date"
                    value={formData.startDate}
                    onChange={(e) => setFormData((prev) => ({ ...prev, startDate: e.target.value }))}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="endDate">Szabadság vége</Label>
                  <Input
                    id="endDate"
                    type="date"
                    value={formData.endDate}
                    onChange={(e) => setFormData((prev) => ({ ...prev, endDate: e.target.value }))}
                    required
                  />
                </div>
              </div>

              {formData.startDate && formData.endDate && (
                <div className="p-3 bg-muted rounded-lg">
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4" />
                    <span className="text-sm font-medium">
                      Időtartam: {calculateDays(formData.startDate, formData.endDate)} nap(ok)
                    </span>
                  </div>
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="reason">Leírása</Label>
                <Textarea
                  id="reason"
                  value={formData.reason}
                  onChange={(e) => setFormData((prev) => ({ ...prev, reason: e.target.value }))}
                  placeholder="Kérelek add meg a kérelmed leírását..."
                  rows={3}
                  required
                />
              </div>

              <Button type="submit" className="w-full">
                <Calendar className="w-4 h-4 mr-2" />
                Szabadság Kérelmezése
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Legutóbbi kérelmeid</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4 max-h-96 overflow-y-auto">
              {requests.filter((req) => req.requestedBy === user.name).length === 0 ? (
                <p className="text-muted-foreground text-center py-4">Még nem nyújtottak be kérelmet</p>
              ) : (
                requests
                  .filter((req) => req.requestedBy === user.name)
                  .slice(0, 5)
                  .map((request) => (
                    <div key={request.id} className="border rounded-lg p-3">
                      <div className="flex justify-between items-start mb-2">
                        <h4 className="font-medium capitalize">{request.leaveType}</h4>
                        <Badge variant={getStatusColor(request.status)}>{request.status}</Badge>
                      </div>
                      <p className="text-sm text-muted-foreground mb-1">
                        {request.startDate} - {request.endDate}
                      </p>
                      <p className="text-sm">{request.reason}</p>
                      {request.status === "Elutasítva" && request.rejectionReason && (
                        <div className="mt-2 p-2 bg-red-50 dark:bg-red-950 border border-red-200 dark:border-red-800 rounded-md text-sm text-red-700 dark:text-red-300">
                          <p className="font-semibold">Elutasítás oka:</p>
                          <p>{request.rejectionReason}</p>
                        </div>
                      )}
                      <p className="text-xs text-muted-foreground mt-2">
                        Kelt: {new Date(request.requestedAt).toLocaleDateString()}
                      </p>
                    </div>
                  ))
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Minden Szabadságkérelem</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Név</TableHead>
                <TableHead>Beosztás</TableHead>
                <TableHead>Szabadság Típusa</TableHead>
                <TableHead>Kezdete</TableHead>
                <TableHead>Vége</TableHead>
                <TableHead>Napok</TableHead>
                <TableHead>Státusz</TableHead>
                <TableHead>Kelt</TableHead>
                {user.isAdmin && <TableHead>Műveletek</TableHead>}
              </TableRow>
            </TableHeader>
            <TableBody>
              {requests.map((request) => (
                <TableRow key={request.id}>
                  <TableCell className="font-medium">{request.requestedBy}</TableCell>
                  <TableCell>{request.rank}</TableCell>
                  <TableCell className="capitalize">{request.leaveType}</TableCell>
                  <TableCell>{request.startDate}</TableCell>
                  <TableCell>{request.endDate}</TableCell>
                  <TableCell>{calculateDays(request.startDate, request.endDate)}</TableCell>
                  <TableCell>
                    <Badge variant={getStatusColor(request.status)}>{request.status}</Badge>
                  </TableCell>
                  <TableCell>{new Date(request.requestedAt).toLocaleDateString()}</TableCell>
                  {user.isAdmin && (
                    <TableCell>
                      <Button variant="outline" size="sm" onClick={() => handleDeleteClick(request.id)} title="Törlés">
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </TableCell>
                  )}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <AlertDialog open={showDeleteConfirmDialog} onOpenChange={setShowDeleteConfirmDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Biztosan törölni szeretné ezt a szabadságkérelmet?</AlertDialogTitle>
            <AlertDialogDescription>
              Ez a művelet nem vonható vissza. Ez véglegesen törli a szabadságkérelmet.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={cancelDelete}>Mégse</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-destructive hover:bg-destructive/90">
              Törlés
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
