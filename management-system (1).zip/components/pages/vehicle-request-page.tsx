"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Car, Trash2, CheckCircle, XCircle, Clock } from "lucide-react"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"

interface VehicleRequestPageProps {
  user: any
}

export function VehicleRequestPage({ user }: VehicleRequestPageProps) {
  const [requests, setRequests] = useState<any[]>([])
  const [availableVehicles, setAvailableVehicles] = useState<any[]>([])
  const [formData, setFormData] = useState({
    selectedVehicle: "",
    requestDate: "",
    assignment: "",
    purpose: "",
  })
  const [showDeleteConfirmDialog, setShowDeleteConfirmDialog] = useState(false)
  const [requestToDeleteId, setRequestToDeleteId] = useState<number | null>(null)
  const [showRejectDialog, setShowRejectDialog] = useState(false)
  const [selectedRequestForReject, setSelectedRequestForReject] = useState<any>(null)
  const [rejectionReason, setRejectionReason] = useState("")

  useEffect(() => {
    const savedRequests = JSON.parse(localStorage.getItem("vehicleRequests") || "[]")
    setRequests(savedRequests)

    // Load available vehicles (out-of-service status)
    const savedVehicles = JSON.parse(localStorage.getItem("vehicles") || "[]")
    const outOfServiceVehicles = savedVehicles.filter((vehicle: any) => vehicle.status === "out-of-service")
    setAvailableVehicles(outOfServiceVehicles)
  }, [])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    const newRequest = {
      ...formData,
      id: Date.now(),
      requestedBy: user.name,
      rank: user.rank,
      requestedAt: new Date().toISOString(),
      status: "Jóváhagyás függőben",
      rejectionReason: undefined,
    }

    const updatedRequests = [newRequest, ...requests]
    setRequests(updatedRequests)
    localStorage.setItem("vehicleRequests", JSON.stringify(updatedRequests))

    setFormData({
      selectedVehicle: "",
      requestDate: "",
      assignment: "",
      purpose: "",
    })
  }

  const handleApprove = (requestId: number) => {
    const updatedRequests = requests.map((req) =>
      req.id === requestId ? { ...req, status: "Elfogadva", approvedAt: new Date().toISOString() } : req,
    )
    setRequests(updatedRequests)
    localStorage.setItem("vehicleRequests", JSON.stringify(updatedRequests))
  }

  const handleRejectClick = (request: any) => {
    setSelectedRequestForReject(request)
    setShowRejectDialog(true)
  }

  const handleRejectConfirm = () => {
    if (selectedRequestForReject && rejectionReason.trim()) {
      const updatedRequests = requests.map((req) =>
        req.id === selectedRequestForReject.id
          ? {
              ...req,
              status: "Elutasítva",
              rejectionReason: rejectionReason.trim(),
              rejectedAt: new Date().toISOString(),
            }
          : req,
      )
      setRequests(updatedRequests)
      localStorage.setItem("vehicleRequests", JSON.stringify(updatedRequests))

      setRejectionReason("")
      setSelectedRequestForReject(null)
      setShowRejectDialog(false)
    }
  }

  const handleDeleteClick = (id: number) => {
    setRequestToDeleteId(id)
    setShowDeleteConfirmDialog(true)
  }

  const confirmDelete = () => {
    if (requestToDeleteId !== null) {
      const updatedRequests = requests.filter((request) => request.id !== requestToDeleteId)
      setRequests(updatedRequests)
      localStorage.setItem("vehicleRequests", JSON.stringify(updatedRequests))
      setRequestToDeleteId(null)
      setShowDeleteConfirmDialog(false)
    }
  }

  const cancelDelete = () => {
    setRequestToDeleteId(null)
    setShowDeleteConfirmDialog(false)
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Elfogadva":
        return "default"
      case "Elutasítva":
        return "destructive"
      case "Jóváhagyás függőben":
        return "secondary"
      default:
        return "secondary"
    }
  }

  const pendingRequests = requests.filter((req) => req.status === "Jóváhagyás függőben")
  const isAdminOrLeader = user.isAdmin || user.isLeader

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Jármű Igénylés</h1>
        <p className="text-muted-foreground">Járművek igénylése szolgálati célokra</p>
      </div>

      {/* Admin/Leader Approval Section */}
      {isAdminOrLeader && pendingRequests.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5" />
              Jóváhagyásra váró jármű igénylések ({pendingRequests.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Név</TableHead>
                  <TableHead>Beosztás</TableHead>
                  <TableHead>Jármű</TableHead>
                  <TableHead>Dátum</TableHead>
                  <TableHead>Beosztás</TableHead>
                  <TableHead>Cél</TableHead>
                  <TableHead>Kérelem dátuma</TableHead>
                  <TableHead>Műveletek</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {pendingRequests.map((request) => (
                  <TableRow key={request.id}>
                    <TableCell className="font-medium">{request.requestedBy}</TableCell>
                    <TableCell>{request.rank}</TableCell>
                    <TableCell>
                      {(() => {
                        const vehicle = availableVehicles.find((v) => v.id.toString() === request.selectedVehicle)
                        return vehicle ? `${vehicle.year} ${vehicle.make} ${vehicle.model}` : request.selectedVehicle
                      })()}
                    </TableCell>
                    <TableCell>{request.requestDate}</TableCell>
                    <TableCell>{request.assignment}</TableCell>
                    <TableCell className="max-w-xs truncate">{request.purpose}</TableCell>
                    <TableCell>{new Date(request.requestedAt).toLocaleDateString()}</TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          onClick={() => handleApprove(request.id)}
                          className="bg-green-600 hover:bg-green-700"
                        >
                          <CheckCircle className="w-4 h-4 mr-1" />
                          Jóváhagyás
                        </Button>
                        <Button size="sm" variant="destructive" onClick={() => handleRejectClick(request)}>
                          <XCircle className="w-4 h-4 mr-1" />
                          Elutasítás
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Új jármű igénylés</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="selectedVehicle">Elérhető jármű</Label>
                <Select
                  value={formData.selectedVehicle}
                  onValueChange={(value) => setFormData((prev) => ({ ...prev, selectedVehicle: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Válasszon egy elérhető járművet" />
                  </SelectTrigger>
                  <SelectContent>
                    {availableVehicles.length === 0 ? (
                      <SelectItem value="" disabled>
                        Nincs elérhető jármű
                      </SelectItem>
                    ) : (
                      availableVehicles.map((vehicle) => (
                        <SelectItem key={vehicle.id} value={`${vehicle.id}`}>
                          {vehicle.year} {vehicle.make} {vehicle.model} - {vehicle.licensePlate}
                        </SelectItem>
                      ))
                    )}
                  </SelectContent>
                </Select>
                {availableVehicles.length === 0 && (
                  <p className="text-sm text-muted-foreground">
                    Jelenleg nincsenek használaton kívüli járművek. Kérjük, vegye fel a kapcsolatot a járműkezelővel.
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="requestDate">Igénylés dátuma</Label>
                <Input
                  id="requestDate"
                  type="date"
                  value={formData.requestDate}
                  onChange={(e) => setFormData((prev) => ({ ...prev, requestDate: e.target.value }))}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="assignment">Beosztás</Label>
                <Input
                  id="assignment"
                  value={formData.assignment}
                  onChange={(e) => setFormData((prev) => ({ ...prev, assignment: e.target.value }))}
                  placeholder="Milyen beosztásra igényli?"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="purpose">Igénylés célja</Label>
                <Textarea
                  id="purpose"
                  value={formData.purpose}
                  onChange={(e) => setFormData((prev) => ({ ...prev, purpose: e.target.value }))}
                  placeholder="Kérem, adja meg az igénylés célját..."
                  rows={3}
                  required
                />
              </div>

              <Button type="submit" className="w-full">
                <Car className="w-4 h-4 mr-2" />
                Jármű Igénylése
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Legutóbbi igényléseim</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4 max-h-96 overflow-y-auto">
              {requests.filter((req) => req.requestedBy === user.name).length === 0 ? (
                <p className="text-muted-foreground text-center py-4">Még nem nyújtottak be jármű igénylést</p>
              ) : (
                requests
                  .filter((req) => req.requestedBy === user.name)
                  .slice(0, 5)
                  .map((request) => (
                    <div key={request.id} className="border rounded-lg p-3">
                      <div className="flex justify-between items-start mb-2">
                        <h4 className="font-medium">
                          {(() => {
                            const vehicle = availableVehicles.find((v) => v.id.toString() === request.selectedVehicle)
                            return vehicle
                              ? `${vehicle.year} ${vehicle.make} ${vehicle.model}`
                              : request.selectedVehicle
                          })()}
                        </h4>
                        <Badge variant={getStatusColor(request.status)}>{request.status}</Badge>
                      </div>
                      <p className="text-sm text-muted-foreground mb-1">Dátum: {request.requestDate}</p>
                      <p className="text-sm">Beosztás: {request.assignment}</p>
                      <p className="text-sm">{request.purpose}</p>
                      {request.status === "Elutasítva" && request.rejectionReason && (
                        <div className="mt-2 p-2 bg-red-50 dark:bg-red-950 border border-red-200 dark:border-red-800 rounded-md text-sm text-red-700 dark:text-red-300">
                          <p className="font-semibold">Elutasítás oka:</p>
                          <p>{request.rejectionReason}</p>
                        </div>
                      )}
                      <p className="text-xs text-muted-foreground mt-2">
                        Kelt: {new Date(request.requestedAt).toLocaleDateString()}
                      </p>
                    </div>
                  ))
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Minden Jármű Igénylés</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Név</TableHead>
                <TableHead>Beosztás</TableHead>
                <TableHead>Jármű típusa</TableHead>
                <TableHead>Dátum</TableHead>
                <TableHead>Beosztás</TableHead>
                <TableHead>Státusz</TableHead>
                <TableHead>Kelt</TableHead>
                {user.isAdmin && <TableHead>Műveletek</TableHead>}
              </TableRow>
            </TableHeader>
            <TableBody>
              {requests.map((request) => (
                <TableRow key={request.id}>
                  <TableCell className="font-medium">{request.requestedBy}</TableCell>
                  <TableCell>{request.rank}</TableCell>
                  <TableCell>
                    {(() => {
                      const vehicle = availableVehicles.find((v) => v.id.toString() === request.selectedVehicle)
                      return vehicle
                        ? `${vehicle.year} ${vehicle.make} ${vehicle.model} - ${vehicle.licensePlate}`
                        : request.selectedVehicle
                    })()}
                  </TableCell>
                  <TableCell>{request.requestDate}</TableCell>
                  <TableCell>{request.assignment}</TableCell>
                  <TableCell>
                    <Badge variant={getStatusColor(request.status)}>{request.status}</Badge>
                  </TableCell>
                  <TableCell>{new Date(request.requestedAt).toLocaleDateString()}</TableCell>
                  {user.isAdmin && (
                    <TableCell>
                      <Button variant="outline" size="sm" onClick={() => handleDeleteClick(request.id)} title="Törlés">
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </TableCell>
                  )}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Rejection Dialog */}
      <Dialog open={showRejectDialog} onOpenChange={setShowRejectDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Jármű igénylés elutasítása</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="rejection-reason">Elutasítás oka</Label>
              <Textarea
                id="rejection-reason"
                value={rejectionReason}
                onChange={(e) => setRejectionReason(e.target.value)}
                placeholder="Kérem, adja meg az elutasítás okát..."
                rows={4}
                required
              />
            </div>
            <div className="flex gap-2">
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setShowRejectDialog(false)
                  setRejectionReason("")
                  setSelectedRequestForReject(null)
                }}
                className="flex-1"
              >
                Mégse
              </Button>
              <Button
                type="button"
                variant="destructive"
                onClick={handleRejectConfirm}
                disabled={!rejectionReason.trim()}
                className="flex-1"
              >
                Elutasítás
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <AlertDialog open={showDeleteConfirmDialog} onOpenChange={setShowDeleteConfirmDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Biztosan törölni szeretné ezt a jármű igénylést?</AlertDialogTitle>
            <AlertDialogDescription>
              Ez a művelet nem vonható vissza. Ez véglegesen törli a jármű igénylést.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={cancelDelete}>Mégse</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-destructive hover:bg-destructive/90">
              Törlés
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
