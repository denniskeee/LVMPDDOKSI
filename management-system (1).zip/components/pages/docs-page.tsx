"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Textarea } from "@/components/ui/textarea"
import { Plus, Edit, Trash2, Crown, Users, Building } from "lucide-react"
import { SubDepartmentList } from "./sub-department-list"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

interface DocsPageProps {
  user: any
}

export function DocsPage({ user }: DocsPageProps) {
  const [personnel, setPersonnel] = useState<any[]>([])
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [editingPerson, setEditingPerson] = useState<any>(null)
  const [formData, setFormData] = useState({
    name: "",
    rank: "",
    badgeNumber: "",
    joinedDate: "",
    lastPromotion: "",
    penaltyPoints: 0,
    notes: "",
    isLeader: false,
  })

  // States to hold all sub-department related data for display
  const [allSubDepartments, setAllSubDepartments] = useState<any[]>([])
  const [allSubDepartmentAssignments, setAllSubDepartmentAssignments] = useState<any[]>([])

  const ranks = [
    "Cadet",
    "Police Officer",
    "Police Officer II",
    "Sergeant",
    "Lieutenant",
    "Captain",
    "Deputy Chief",
    "Assistant Sheriff",
    "Undersheriff",
    "Sheriff",
  ]

  useEffect(() => {
    // Load personnel data from localStorage (these are the main users)
    const users = JSON.parse(localStorage.getItem("users") || "[]")
    // Ensure each user has an isLeader property, default to false if missing
    const approvedUsers = users
      .filter((u: any) => u.approved)
      .map((u: any) => ({
        ...u,
        isLeader: u.isLeader ?? false,
      }))
    setPersonnel(approvedUsers)

    // Load all sub-departments and sub-department assignments for display
    const savedSubDepartments = JSON.parse(localStorage.getItem("subDepartments") || "[]")
    setAllSubDepartments(savedSubDepartments)

    const savedSubDepartmentAssignments = JSON.parse(localStorage.getItem("subDepartmentAssignments") || "[]")
    setAllSubDepartmentAssignments(savedSubDepartmentAssignments)
  }, [])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (editingPerson) {
      // Update existing person
      const updatedPersonnel = personnel.map((person) =>
        person.id === editingPerson.id ? { ...person, ...formData } : person,
      )
      setPersonnel(updatedPersonnel)

      // Update in localStorage
      const users = JSON.parse(localStorage.getItem("users") || "[]")
      const updatedUsers = users.map((u: any) => (u.id === editingPerson.id ? { ...u, ...formData } : u))
      localStorage.setItem("users", JSON.stringify(updatedUsers))
    } else {
      // Add new person
      const newPerson = {
        ...formData,
        id: Date.now(),
        approved: true,
        isLeader: false,
        email: `${formData.name.toLowerCase().replace(/\s+/g, ".")}@police.local`,
        password: "temp123", // Temporary password
        isAdmin: false,
      }
      const updatedPersonnel = [...personnel, newPerson]
      setPersonnel(updatedPersonnel)

      // Update localStorage
      const users = JSON.parse(localStorage.getItem("users") || "[]")
      users.push(newPerson)
      localStorage.setItem("users", JSON.stringify(users))
    }

    resetForm()
  }

  const resetForm = () => {
    setFormData({
      name: "",
      rank: "",
      badgeNumber: "",
      joinedDate: "",
      lastPromotion: "",
      penaltyPoints: 0,
      notes: "",
      isLeader: false,
    })
    setEditingPerson(null)
    setIsAddDialogOpen(false)
  }

  const handleEdit = (person: any) => {
    setEditingPerson(person)
    setFormData({
      name: person.name,
      rank: person.rank,
      badgeNumber: person.badgeNumber || "",
      joinedDate: person.joinedDate,
      lastPromotion: person.lastPromotion || "",
      penaltyPoints: person.penaltyPoints || 0,
      notes: person.notes || "",
      isLeader: person.isLeader ?? false,
    })
    setIsAddDialogOpen(true)
  }

  const handleDelete = (id: number) => {
    if (confirm("Biztosan törölni szeretné ezt a személyt?")) {
      const updatedPersonnel = personnel.filter((person) => person.id !== id)
      setPersonnel(updatedPersonnel)

      // Update localStorage
      const users = JSON.parse(localStorage.getItem("users") || "[]")
      const updatedUsers = users.filter((u: any) => u.id !== id)
      localStorage.setItem("users", JSON.stringify(updatedUsers))

      // Also delete any associated sub-department assignments for this user
      const allAssignments = JSON.parse(localStorage.getItem("subDepartmentAssignments") || "[]")
      const remainingAssignments = allAssignments.filter((assignment: any) => assignment.userId !== id)
      localStorage.setItem("subDepartmentAssignments", JSON.stringify(remainingAssignments))
      setAllSubDepartmentAssignments(remainingAssignments)
    }
  }

  const handleToggleLeaderStatus = (personId: number) => {
    const updatedPersonnel = personnel.map((person) =>
      person.id === personId ? { ...person, isLeader: !person.isLeader } : person,
    )
    setPersonnel(updatedPersonnel)

    // Update in localStorage
    const users = JSON.parse(localStorage.getItem("users") || "[]")
    const updatedUsers = users.map((u: any) => (u.id === personId ? { ...u, isLeader: !u.isLeader } : u))
    localStorage.setItem("users", JSON.stringify(updatedUsers))
  }

  // Function to get all sub-department names for a person (user)
  const getSubDepartmentNamesForPerson = (userId: number) => {
    const assignments = allSubDepartmentAssignments.filter((assignment) => assignment.userId === userId)
    return assignments
      .map((assignment) => {
        const subDept = allSubDepartments.find((dept) => dept.id === assignment.subDepartmentId)
        return subDept ? subDept.name : null
      })
      .filter(Boolean)
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Állományi Nyilvántartás</h1>
          <p className="text-muted-foreground">Állományi nyilvántartások és információk kezelése</p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => setEditingPerson(null)}>
              <Plus className="w-4 h-4 mr-2" />
              Új tag hozzáadása
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>{editingPerson ? "Személy szerkesztése" : "Új személy hozzáadása"}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Név</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData((prev) => ({ ...prev, name: e.target.value }))}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="rank">Beosztás</Label>
                <Select
                  value={formData.rank}
                  onValueChange={(value) => setFormData((prev) => ({ ...prev, rank: value }))}
                  required
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Válassza ki a beosztást" />
                  </SelectTrigger>
                  <SelectContent>
                    {ranks.map((rank) => (
                      <SelectItem key={rank} value={rank}>
                        {rank}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="badgeNumber">Jelvényszám</Label>
                <Input
                  id="badgeNumber"
                  value={formData.badgeNumber}
                  onChange={(e) => setFormData((prev) => ({ ...prev, badgeNumber: e.target.value }))}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="joinedDate">Csatlakozás Dátuma</Label>
                <Input
                  id="joinedDate"
                  type="date"
                  value={formData.joinedDate}
                  onChange={(e) => setFormData((prev) => ({ ...prev, joinedDate: e.target.value }))}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="lastPromotion">Utolsó Ranglépés</Label>
                <Input
                  id="lastPromotion"
                  type="date"
                  value={formData.lastPromotion}
                  onChange={(e) => setFormData((prev) => ({ ...prev, lastPromotion: e.target.value }))}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="penaltyPoints">Hibapont</Label>
                <Input
                  id="penaltyPoints"
                  type="number"
                  value={formData.penaltyPoints}
                  onChange={(e) =>
                    setFormData((prev) => ({ ...prev, penaltyPoints: Number.parseInt(e.target.value) || 0 }))
                  }
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="notes">Megjegyzés</Label>
                <Textarea
                  id="notes"
                  value={formData.notes}
                  onChange={(e) => setFormData((prev) => ({ ...prev, notes: e.target.value }))}
                  rows={3}
                />
              </div>
              <div className="flex gap-2">
                <Button type="button" variant="outline" onClick={resetForm} className="flex-1 bg-transparent">
                  Mégse
                </Button>
                <Button type="submit" className="flex-1">
                  {editingPerson ? "Frissítés" : "Hozzáadás"}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Statistics Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Összes Tag</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{personnel.length}</div>
            <p className="text-xs text-muted-foreground">Aktív személyzet</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Vezetők</CardTitle>
            <Crown className="h-4 w-4 text-yellow-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">{personnel.filter((p) => p.isLeader).length}</div>
            <p className="text-xs text-muted-foreground">Vezetői pozícióban</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Adminisztrátorok</CardTitle>
            <Building className="h-4 w-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{personnel.filter((p) => p.isAdmin).length}</div>
            <p className="text-xs text-muted-foreground">Rendszergazdák</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Alosztályok</CardTitle>
            <Building className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{allSubDepartments.length}</div>
            <p className="text-xs text-muted-foreground">Aktív alosztályok</p>
          </CardContent>
        </Card>
      </div>

      {/* Tabs for different sections */}
      <Tabs defaultValue="members" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="members" className="flex items-center gap-2">
            <Users className="w-4 h-4" />
            Tagok
          </TabsTrigger>
          <TabsTrigger value="departments" className="flex items-center gap-2">
            <Building className="w-4 h-4" />
            Alosztályok
          </TabsTrigger>
        </TabsList>

        <TabsContent value="members" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5" />
                Rendőrségi Tagok ({personnel.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              {personnel.length === 0 ? (
                <p className="text-muted-foreground text-center py-8">Még nincsenek tagok a rendszerben.</p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Név</TableHead>
                      <TableHead>Beosztás</TableHead>
                      <TableHead>Jelvényszám</TableHead>
                      <TableHead>Csatlakozás</TableHead>
                      <TableHead>Státusz</TableHead>
                      <TableHead>Alosztályok</TableHead>
                      <TableHead>Kezelés</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {personnel.map((person) => {
                      const subDepartmentNames = getSubDepartmentNamesForPerson(person.id)
                      return (
                        <TableRow key={person.id}>
                          <TableCell className="font-medium">
                            <div className="flex items-center gap-2">
                              {person.name}
                              {person.isAdmin && (
                                <Badge variant="destructive" className="text-xs">
                                  Admin
                                </Badge>
                              )}
                              {person.isLeader && <Crown className="h-4 w-4 text-yellow-500" title="Vezető" />}
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline">{person.rank}</Badge>
                          </TableCell>
                          <TableCell className="font-mono text-sm">{person.badgeNumber || "N/A"}</TableCell>
                          <TableCell>{person.joinedDate}</TableCell>
                          <TableCell>
                            <div className="flex flex-col gap-1">
                              <Badge variant="default" className="text-xs w-fit">
                                Aktív
                              </Badge>
                              {person.penaltyPoints > 0 && (
                                <Badge variant="destructive" className="text-xs w-fit">
                                  {person.penaltyPoints} hibapont
                                </Badge>
                              )}
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex flex-wrap gap-1">
                              {subDepartmentNames.length > 0 ? (
                                subDepartmentNames.map((name: string) => (
                                  <Badge key={name} variant="secondary" className="text-xs">
                                    {name}
                                  </Badge>
                                ))
                              ) : (
                                <span className="text-xs text-muted-foreground">Nincs hozzárendelés</span>
                              )}
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex gap-2">
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleEdit(person)}
                                title="Szerkesztés"
                              >
                                <Edit className="w-4 h-4" />
                              </Button>
                              {user.isAdmin && (
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleToggleLeaderStatus(person.id)}
                                  title={
                                    person.isLeader ? "Vezetői státusz eltávolítása" : "Vezetői státusz hozzáadása"
                                  }
                                >
                                  <Crown
                                    className={`h-4 w-4 ${person.isLeader ? "text-yellow-500" : "text-muted-foreground"}`}
                                  />
                                </Button>
                              )}
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleDelete(person.id)}
                                title="Törlés"
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      )
                    })}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="departments" className="space-y-4">
          <SubDepartmentList onSelectSubDepartment={() => {}} />
        </TabsContent>
      </Tabs>
    </div>
  )
}
