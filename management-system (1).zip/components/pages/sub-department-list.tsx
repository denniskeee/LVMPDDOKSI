"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Textarea } from "@/components/ui/textarea"
import { Plus, Edit, Trash2, Users } from "lucide-react"

interface SubDepartmentListProps {
  onSelectSubDepartment: (subDepartmentId: number, subDepartmentName: string) => void
}

export function SubDepartmentList({ onSelectSubDepartment }: SubDepartmentListProps) {
  const [subDepartments, setSubDepartments] = useState<any[]>([])
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [editingSubDepartment, setEditingSubDepartment] = useState<any>(null)
  const [formData, setFormData] = useState({
    name: "",
    description: "",
  })

  useEffect(() => {
    const savedSubDepartments = JSON.parse(localStorage.getItem("subDepartments") || "[]")
    setSubDepartments(savedSubDepartments)
  }, [])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (editingSubDepartment) {
      const updatedSubDepartments = subDepartments.map((dept) =>
        dept.id === editingSubDepartment.id ? { ...dept, ...formData } : dept,
      )
      setSubDepartments(updatedSubDepartments)
      localStorage.setItem("subDepartments", JSON.stringify(updatedSubDepartments))
    } else {
      const newSubDepartment = {
        ...formData,
        id: Date.now(),
        createdAt: new Date().toISOString(),
      }
      const updatedSubDepartments = [...subDepartments, newSubDepartment]
      setSubDepartments(updatedSubDepartments)
      localStorage.setItem("subDepartments", JSON.stringify(updatedSubDepartments))
    }

    resetForm()
  }

  const resetForm = () => {
    setFormData({
      name: "",
      description: "",
    })
    setEditingSubDepartment(null)
    setIsAddDialogOpen(false)
  }

  const handleEdit = (subDepartment: any) => {
    setEditingSubDepartment(subDepartment)
    setFormData({
      name: subDepartment.name,
      description: subDepartment.description || "",
    })
    setIsAddDialogOpen(true)
  }

  const handleDelete = (id: number) => {
    if (confirm("Biztosan törölni szeretné ezt az alosztályt? Ez törli az összes hozzárendelt személyt is.")) {
      const updatedSubDepartments = subDepartments.filter((dept) => dept.id !== id)
      setSubDepartments(updatedSubDepartments)
      localStorage.setItem("subDepartments", JSON.stringify(updatedSubDepartments))

      // Also delete associated personnel
      const allSubDepartmentPersonnel = JSON.parse(localStorage.getItem("subDepartmentPersonnel") || "[]")
      const remainingPersonnel = allSubDepartmentPersonnel.filter((person: any) => person.subDepartmentId !== id)
      localStorage.setItem("subDepartmentPersonnel", JSON.stringify(remainingPersonnel))
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Alozstályok Kezelése</h2>
          <p className="text-muted-foreground">Alosztályok létrehozása és kezelése</p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => setEditingSubDepartment(null)}>
              <Plus className="w-4 h-4 mr-2" />
              Új alosztály
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>{editingSubDepartment ? "Alosztály szerkesztése" : "Új alosztály hozzáadása"}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="sub-department-name">Név</Label>
                <Input
                  id="sub-department-name"
                  value={formData.name}
                  onChange={(e) => setFormData((prev) => ({ ...prev, name: e.target.value }))}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="sub-department-description">Leírás</Label>
                <Textarea
                  id="sub-department-description"
                  value={formData.description}
                  onChange={(e) => setFormData((prev) => ({ ...prev, description: e.target.value }))}
                  rows={3}
                />
              </div>
              <div className="flex gap-2">
                <Button type="button" variant="outline" onClick={resetForm} className="flex-1 bg-transparent">
                  Mégse
                </Button>
                <Button type="submit" className="flex-1">
                  {editingSubDepartment ? "Frissítés" : "Hozzáadás"}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Alosztályok</CardTitle>
        </CardHeader>
        <CardContent>
          {subDepartments.length === 0 ? (
            <p className="text-muted-foreground text-center py-4">Még nincsenek alosztályok.</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Név</TableHead>
                  <TableHead>Leírás</TableHead>
                  <TableHead>Létrehozva</TableHead>
                  <TableHead>Műveletek</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {subDepartments.map((dept) => (
                  <TableRow key={dept.id}>
                    <TableCell className="font-medium">{dept.name}</TableCell>
                    <TableCell className="max-w-xs truncate">{dept.description || "Nincs leírás"}</TableCell>
                    <TableCell>{new Date(dept.createdAt).toLocaleDateString()}</TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => onSelectSubDepartment(dept.id, dept.name)}
                          title="Emberek kezelése"
                        >
                          <Users className="w-4 h-4" />
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => handleEdit(dept)} title="Szerkesztés">
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => handleDelete(dept.id)} title="Törlés">
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
