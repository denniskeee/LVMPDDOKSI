"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Plus, Edit, Trash2, Gavel, Clock, CheckCircle } from "lucide-react"

interface WeaponReportPageProps {
  user: any
}

export function WeaponReportPage({ user }: WeaponReportPageProps) {
  const [weaponReports, setWeaponReports] = useState<any[]>([])
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [editingReport, setEditingReport] = useState<any>(null)
  const [formData, setFormData] = useState({
    weaponType: "",
    serialNumber: "",
    ownerName: "",
    reportDate: "",
    validityPeriodMonths: "3",
    reportedBy: user.name,
    reason: "",
    status: "reported",
    expirationDate: "",
    price: 0,
  })

  const weaponTypes = [
    "Glock 17",
    "Glock 19",
    "HP USP 45",
    "Colt 1911",
    "Colt 45",
    "Vipera",
    "Boxer",
    "S&W 66",
    "Kés",
    "Egyéb",
  ]

  useEffect(() => {
    const savedReports = JSON.parse(localStorage.getItem("weaponReports") || "[]")
    setWeaponReports(savedReports)
  }, [])

  const calculateExpirationDate = (reportDate: string, validityMonths: string): string => {
    if (!reportDate || !validityMonths) return ""
    const date = new Date(reportDate)
    date.setMonth(date.getMonth() + Number.parseInt(validityMonths, 10))
    return date.toISOString().split("T")[0]
  }

  const calculatePrice = (validityMonths: string): number => {
    const basePricePerMonth = 1500000
    return Number.parseInt(validityMonths, 10) * basePricePerMonth
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    const expirationDate = calculateExpirationDate(formData.reportDate, formData.validityPeriodMonths)

    if (editingReport) {
      const updatedReports = weaponReports.map((report) =>
        report.id === editingReport.id
          ? { ...report, ...formData, expirationDate, price: calculatePrice(formData.validityPeriodMonths) }
          : report,
      )
      setWeaponReports(updatedReports)
      localStorage.setItem("weaponReports", JSON.stringify(updatedReports))
    } else {
      const newReport = {
        ...formData,
        id: Date.now(),
        submittedAt: new Date().toISOString(),
        expirationDate,
        price: calculatePrice(formData.validityPeriodMonths),
      }
      const updatedReports = [...weaponReports, newReport]
      setWeaponReports(updatedReports)
      localStorage.setItem("weaponReports", JSON.stringify(updatedReports))
    }

    resetForm()
  }

  const resetForm = () => {
    setFormData({
      weaponType: "",
      serialNumber: "",
      ownerName: "",
      reportDate: "",
      validityPeriodMonths: "3",
      reportedBy: user.name,
      reason: "",
      status: "reported",
      expirationDate: "",
      price: 0,
    })
    setEditingReport(null)
    setIsAddDialogOpen(false)
  }

  const handleEdit = (report: any) => {
    setEditingReport(report)
    setFormData({
      weaponType: report.weaponType,
      serialNumber: report.serialNumber,
      ownerName: report.ownerName,
      reportDate: report.reportDate,
      validityPeriodMonths: report.validityPeriodMonths || "3",
      reportedBy: report.reportedBy,
      reason: report.reason,
      status: report.status,
      expirationDate: report.expirationDate || "",
      price: report.price || 0,
    })
    setIsAddDialogOpen(true)
  }

  const handleDelete = (id: number) => {
    if (confirm("Biztosan törölni szeretné ezt a fegyver bejelentést?")) {
      const updatedReports = weaponReports.filter((report) => report.id !== id)
      setWeaponReports(updatedReports)
      localStorage.setItem("weaponReports", JSON.stringify(updatedReports))
    }
  }

  const handleStatusChange = (report: any, newStatus: "reported" | "under-investigation" | "closed") => {
    const updatedReports = weaponReports.map((r) => (r.id === report.id ? { ...r, status: newStatus } : r))
    setWeaponReports(updatedReports)
    localStorage.setItem("weaponReports", JSON.stringify(updatedReports))
  }

  const getProcessingStatusColor = (status: string) => {
    switch (status) {
      case "reported":
        return "secondary"
      case "under-investigation":
        return "yellow"
      case "closed":
        return "default"
      default:
        return "secondary"
    }
  }

  const getValidityStatus = (expirationDate: string) => {
    if (!expirationDate) return "unknown"
    const today = new Date()
    today.setHours(0, 0, 0, 0)
    const expiry = new Date(expirationDate)
    expiry.setHours(0, 0, 0, 0)

    if (expiry >= today) {
      return "valid"
    } else {
      return "expired"
    }
  }

  const getValidityColor = (expirationDate: string) => {
    const status = getValidityStatus(expirationDate)
    return status === "valid" ? "default" : "destructive"
  }

  const validReports = weaponReports.filter((report) => getValidityStatus(report.expirationDate) === "valid")
  const expiredReports = weaponReports.filter((report) => getValidityStatus(report.expirationDate) === "expired")

  const totalReports = weaponReports.length
  const validCount = validReports.length
  const expiredCount = expiredReports.length
  const processingCount = weaponReports.filter((r) => r.status === "under-investigation").length

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Fegyver Bejelentés</h1>
          <p className="text-muted-foreground">Fegyver bejelentések kezelése és nyomon követése</p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => setEditingReport(null)}>
              <Plus className="w-4 h-4 mr-2" />
              Új fegyver bejelentés hozzáadása
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {editingReport ? "Fegyver bejelentés szerkesztése" : "Új fegyver bejelentés hozzáadása"}
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="weaponType">Fegyver típusa</Label>
                  <Select
                    value={formData.weaponType}
                    onValueChange={(value) => setFormData((prev) => ({ ...prev, weaponType: value }))}
                    required
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Válassza ki a fegyver típusát" />
                    </SelectTrigger>
                    <SelectContent>
                      {weaponTypes.map((type) => (
                        <SelectItem key={type} value={type}>
                          {type}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="serialNumber">Sorozatszám</Label>
                  <Input
                    id="serialNumber"
                    value={formData.serialNumber}
                    onChange={(e) => setFormData((prev) => ({ ...prev, serialNumber: e.target.value }))}
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="ownerName">Tulajdonos neve</Label>
                  <Input
                    id="ownerName"
                    value={formData.ownerName}
                    onChange={(e) => setFormData((prev) => ({ ...prev, ownerName: e.target.value }))}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="reportDate">Bejelentés dátuma</Label>
                  <Input
                    id="reportDate"
                    type="date"
                    value={formData.reportDate}
                    onChange={(e) => setFormData((prev) => ({ ...prev, reportDate: e.target.value }))}
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="validityPeriodMonths">Érvényességi idő (hónap)</Label>
                  <Select
                    value={formData.validityPeriodMonths}
                    onValueChange={(value) => setFormData((prev) => ({ ...prev, validityPeriodMonths: value }))}
                    required
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Válassza ki az érvényességi időt" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1">1 hónap</SelectItem>
                      <SelectItem value="3">3 hónap</SelectItem>
                      <SelectItem value="6">6 hónap</SelectItem>
                      <SelectItem value="12">12 hónap</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="expirationDate">Lejárat dátuma</Label>
                  <Input
                    id="expirationDate"
                    type="date"
                    value={calculateExpirationDate(formData.reportDate, formData.validityPeriodMonths)}
                    disabled
                    className="bg-muted"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="price">Bejelentés ára</Label>
                <Input
                  id="price"
                  value={`${calculatePrice(formData.validityPeriodMonths).toLocaleString("en-US")} $`}
                  disabled
                  className="bg-muted"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="reportedBy">Bejelentő</Label>
                <Input
                  id="reportedBy"
                  value={formData.reportedBy}
                  onChange={(e) => setFormData((prev) => ({ ...prev, reportedBy: e.target.value }))}
                  disabled
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="reason">Bejelentés oka</Label>
                <Textarea
                  id="reason"
                  value={formData.reason}
                  onChange={(e) => setFormData((prev) => ({ ...prev, reason: e.target.value }))}
                  placeholder="Kérem, adja meg a bejelentés okát..."
                  rows={3}
                  required
                />
              </div>

              <div className="flex gap-2">
                <Button type="button" variant="outline" onClick={resetForm} className="flex-1 bg-transparent">
                  Mégse
                </Button>
                <Button type="submit" className="flex-1">
                  {editingReport ? "Frissítés" : "Hozzáadás"}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Összes bejelentés</CardTitle>
            <Gavel className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalReports}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Érvényes</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{validCount}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Lejárt</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{expiredCount}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Kivizsgálás alatt</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">{processingCount}</div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Érvényes Fegyver Bejelentések</CardTitle>
        </CardHeader>
        <CardContent>
          {validReports.length === 0 ? (
            <p className="text-muted-foreground text-center py-4">Nincsenek érvényes fegyver bejelentések.</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Fegyver</TableHead>
                  <TableHead>Sorozatszám</TableHead>
                  <TableHead>Tulajdonos</TableHead>
                  <TableHead>Bejelentés Dátuma</TableHead>
                  <TableHead>Lejárat Dátuma</TableHead>
                  <TableHead>Bejelentő</TableHead>
                  <TableHead>Feldolgozási Státusz</TableHead>
                  <TableHead>Műveletek</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {validReports.map((report) => (
                  <TableRow key={report.id}>
                    <TableCell className="font-medium">{report.weaponType}</TableCell>
                    <TableCell>{report.serialNumber}</TableCell>
                    <TableCell>{report.ownerName}</TableCell>
                    <TableCell>{report.reportDate}</TableCell>
                    <TableCell>
                      <Badge variant={getValidityColor(report.expirationDate)}>{report.expirationDate}</Badge>
                    </TableCell>
                    <TableCell>{report.reportedBy}</TableCell>
                    <TableCell>
                      <Badge variant={getProcessingStatusColor(report.status)}>
                        {report.status === "reported"
                          ? "Bejelentve"
                          : report.status === "under-investigation"
                            ? "Kivizsgálás alatt"
                            : "Lezárva"}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" onClick={() => handleEdit(report)} title="Szerkesztés">
                          <Edit className="w-4 h-4" />
                        </Button>
                        {report.status === "reported" && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleStatusChange(report, "under-investigation")}
                            title="Kivizsgálás alá helyezés"
                          >
                            <Clock className="w-4 h-4" />
                          </Button>
                        )}
                        {report.status === "under-investigation" && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleStatusChange(report, "closed")}
                            title="Lezárás"
                          >
                            <CheckCircle className="w-4 h-4" />
                          </Button>
                        )}
                        <Button variant="outline" size="sm" onClick={() => handleDelete(report.id)} title="Törlés">
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Lejárt Fegyver Bejelentések</CardTitle>
        </CardHeader>
        <CardContent>
          {expiredReports.length === 0 ? (
            <p className="text-muted-foreground text-center py-4">Nincsenek lejárt fegyver bejelentések.</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Fegyver</TableHead>
                  <TableHead>Sorozatszám</TableHead>
                  <TableHead>Tulajdonos</TableHead>
                  <TableHead>Bejelentés Dátuma</TableHead>
                  <TableHead>Lejárat Dátuma</TableHead>
                  <TableHead>Bejelentő</TableHead>
                  <TableHead>Feldolgozási Státusz</TableHead>
                  <TableHead>Műveletek</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {expiredReports.map((report) => (
                  <TableRow key={report.id}>
                    <TableCell className="font-medium">{report.weaponType}</TableCell>
                    <TableCell>{report.serialNumber}</TableCell>
                    <TableCell>{report.ownerName}</TableCell>
                    <TableCell>{report.reportDate}</TableCell>
                    <TableCell>
                      <Badge variant={getValidityColor(report.expirationDate)}>{report.expirationDate}</Badge>
                    </TableCell>
                    <TableCell>{report.reportedBy}</TableCell>
                    <TableCell>
                      <Badge variant={getProcessingStatusColor(report.status)}>
                        {report.status === "reported"
                          ? "Bejelentve"
                          : report.status === "under-investigation"
                            ? "Kivizsgálás alatt"
                            : "Lezárva"}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" onClick={() => handleEdit(report)} title="Szerkesztés">
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => handleDelete(report.id)} title="Törlés">
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
