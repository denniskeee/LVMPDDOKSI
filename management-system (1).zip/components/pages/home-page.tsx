"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { AnnouncementForm } from "@/components/announcement-form"
import { Users, FileText, Calendar, Car, Shield, Gavel, Bell, Plus, TrendingUp, Clock } from "lucide-react"

interface HomePageProps {
  user: any
  onPageChange?: (page: string) => void
}

export function HomePage({ user, onPageChange }: HomePageProps) {
  const [announcements, setAnnouncements] = useState<any[]>([])
  const [showAnnouncementForm, setShowAnnouncementForm] = useState(false)
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalReports: 0,
    pendingLeaveRequests: 0,
    totalVehicles: 0,
    seizedVehicles: 0,
    weaponReports: 0,
  })

  useEffect(() => {
    // Load announcements
    const savedAnnouncements = JSON.parse(localStorage.getItem("announcements") || "[]")
    setAnnouncements(savedAnnouncements.slice(0, 5)) // Show only latest 5

    // Calculate stats
    const users = JSON.parse(localStorage.getItem("users") || "[]")
    const reports = JSON.parse(localStorage.getItem("reports") || "[]")
    const leaveRequests = JSON.parse(localStorage.getItem("leaveRequests") || "[]")
    const vehicles = JSON.parse(localStorage.getItem("vehicles") || "[]")
    const seizedCars = JSON.parse(localStorage.getItem("seizedCars") || "[]")
    const weaponReports = JSON.parse(localStorage.getItem("weaponReports") || "[]")

    setStats({
      totalUsers: users.filter((u: any) => u.approved).length,
      totalReports: reports.length,
      pendingLeaveRequests: leaveRequests.filter((r: any) => r.status === "Jóváhagyás függőben").length,
      totalVehicles: vehicles.length,
      seizedVehicles: seizedCars.filter((c: any) => c.status !== "released").length,
      weaponReports: weaponReports.length,
    })
  }, [])

  const handleAnnouncementAdded = (newAnnouncement: any) => {
    const updatedAnnouncements = [newAnnouncement, ...announcements]
    setAnnouncements(updatedAnnouncements.slice(0, 5))
    setShowAnnouncementForm(false)
  }

  const getGreeting = () => {
    const hour = new Date().getHours()
    if (hour < 12) return "Jó reggelt"
    if (hour < 18) return "Jó napot"
    return "Jó estét"
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "destructive"
      case "medium":
        return "secondary"
      case "low":
        return "outline"
      default:
        return "secondary"
    }
  }

  const getPriorityText = (priority: string) => {
    switch (priority) {
      case "high":
        return "Magas"
      case "medium":
        return "Közepes"
      case "low":
        return "Alacsony"
      default:
        return "Közepes"
    }
  }

  return (
    <div className="space-y-6">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-800 text-white rounded-lg p-6">
        <h1 className="text-2xl font-bold mb-2">
          {getGreeting()}, {user.name}!
        </h1>
        <p className="text-blue-100">
          Beosztás: {user.rank} | Jelvényszám: {user.badgeNumber}
        </p>
        {user.isAdmin && <Badge className="mt-2 bg-red-600 hover:bg-red-700">Rendszergazda</Badge>}
      </div>

      {/* Quick Stats */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Aktív Felhasználók</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalUsers}</div>
            <p className="text-xs text-muted-foreground">Jóváhagyott felhasználók</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Jelentések</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalReports}</div>
            <p className="text-xs text-muted-foreground">Összes jelentés</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Szabadságkérelmek</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{stats.pendingLeaveRequests}</div>
            <p className="text-xs text-muted-foreground">Jóváhagyásra vár</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Járműpark</CardTitle>
            <Car className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalVehicles}</div>
            <p className="text-xs text-muted-foreground">Összes jármű</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Lefoglalt járművek</CardTitle>
            <Shield className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{stats.seizedVehicles}</div>
            <p className="text-xs text-muted-foreground">Aktív lefoglalások</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Fegyver bejelentések</CardTitle>
            <Gavel className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.weaponReports}</div>
            <p className="text-xs text-muted-foreground">Összes bejelentés</p>
          </CardContent>
        </Card>
      </div>

      {/* Announcements Section */}
      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Bell className="h-5 w-5" />
              Legutóbbi közlemények
            </CardTitle>
            {(user.isAdmin || user.isLeader) && (
              <Button size="sm" onClick={() => setShowAnnouncementForm(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Új közlemény
              </Button>
            )}
          </CardHeader>
          <CardContent>
            {announcements.length === 0 ? (
              <p className="text-muted-foreground text-center py-4">Még nincsenek közlemények</p>
            ) : (
              <div className="space-y-4">
                {announcements.map((announcement) => (
                  <div
                    key={announcement.id}
                    className={`border rounded-lg p-4 space-y-2 ${
                      announcement.effectType === "glow"
                        ? "animate-glow"
                        : announcement.effectType === "shake"
                          ? "animate-shake"
                          : announcement.effectType === "pulse"
                            ? "animate-pulse-slow"
                            : ""
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <h4 className="font-medium">{announcement.title}</h4>
                      <Badge variant={getPriorityColor(announcement.priority)}>
                        {getPriorityText(announcement.priority)}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground">{announcement.content}</p>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <Clock className="w-3 h-3" />
                      {new Date(announcement.createdAt).toLocaleString()}
                      <span>•</span>
                      <span>{announcement.author}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              Gyors műveletek
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-3">
              <Button
                variant="outline"
                className="justify-start h-auto p-4 bg-transparent"
                onClick={() => onPageChange("reports")}
              >
                <FileText className="w-4 h-4 mr-3" />
                <div className="text-left">
                  <div className="font-medium">Új jelentés</div>
                  <div className="text-sm text-muted-foreground">Esemény vagy incidens jelentése</div>
                </div>
              </Button>

              <Button
                variant="outline"
                className="justify-start h-auto p-4 bg-transparent"
                onClick={() => onPageChange("leave-requests")}
              >
                <Calendar className="w-4 h-4 mr-3" />
                <div className="text-left">
                  <div className="font-medium">Szabadság kérelem</div>
                  <div className="text-sm text-muted-foreground">Új szabadságkérelem beküldése</div>
                </div>
              </Button>

              <Button
                variant="outline"
                className="justify-start h-auto p-4 bg-transparent"
                onClick={() => onPageChange("docs")}
              >
                <Users className="w-4 h-4 mr-3" />
                <div className="text-left">
                  <div className="font-medium">Személyzet kezelése</div>
                  <div className="text-sm text-muted-foreground">Alosztályok és személyzet</div>
                </div>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Announcement Form Modal */}
      {showAnnouncementForm && (
        <AnnouncementForm
          user={user}
          onAnnouncementAdded={handleAnnouncementAdded}
          onClose={() => setShowAnnouncementForm(false)}
        />
      )}
    </div>
  )
}
