"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Textarea } from "@/components/ui/textarea"
import { Plus, Edit, Trash2, ArrowLeft } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface SubDepartmentPersonnelProps {
  subDepartmentId: number
  subDepartmentName: string
  onBack: () => void
}

export function SubDepartmentPersonnel({ subDepartmentId, subDepartmentName, onBack }: SubDepartmentPersonnelProps) {
  const [personnelAssignments, setPersonnelAssignments] = useState<any[]>([])
  const [allUsers, setAllUsers] = useState<any[]>([])
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [editingAssignment, setEditingAssignment] = useState<any>(null)
  const [selectedUserId, setSelectedUserId] = useState<string>("")
  const [assignmentNotes, setAssignmentNotes] = useState<string>("")

  useEffect(() => {
    const users = JSON.parse(localStorage.getItem("users") || "[]")
    setAllUsers(users.filter((u: any) => u.approved))

    const allAssignments = JSON.parse(localStorage.getItem("subDepartmentAssignments") || "[]")
    setPersonnelAssignments(allAssignments.filter((assignment: any) => assignment.subDepartmentId === subDepartmentId))
  }, [subDepartmentId])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    let updatedAllAssignments: any[] = JSON.parse(localStorage.getItem("subDepartmentAssignments") || "[]")

    if (editingAssignment) {
      updatedAllAssignments = updatedAllAssignments.map((assignment: any) =>
        assignment.id === editingAssignment.id ? { ...assignment, notes: assignmentNotes } : assignment,
      )
    } else {
      if (!selectedUserId) return

      const newAssignment = {
        id: Date.now(),
        userId: Number.parseInt(selectedUserId, 10),
        subDepartmentId: subDepartmentId,
        assignedAt: new Date().toISOString(),
        notes: assignmentNotes,
      }
      updatedAllAssignments = [...updatedAllAssignments, newAssignment]
    }

    localStorage.setItem("subDepartmentAssignments", JSON.stringify(updatedAllAssignments))
    setPersonnelAssignments(
      updatedAllAssignments.filter((assignment: any) => assignment.subDepartmentId === subDepartmentId),
    )

    resetForm()
  }

  const resetForm = () => {
    setSelectedUserId("")
    setAssignmentNotes("")
    setEditingAssignment(null)
    setIsAddDialogOpen(false)
  }

  const handleEdit = (assignment: any) => {
    setEditingAssignment(assignment)
    setSelectedUserId(assignment.userId.toString())
    setAssignmentNotes(assignment.notes || "")
    setIsAddDialogOpen(true)
  }

  const handleDelete = (assignmentId: number) => {
    if (confirm("Biztosan törölni szeretné ezt a hozzárendelést?")) {
      const updatedAllAssignments = JSON.parse(localStorage.getItem("subDepartmentAssignments") || "[]")
      const remainingAssignments = updatedAllAssignments.filter((assignment: any) => assignment.id !== assignmentId)
      localStorage.setItem("subDepartmentAssignments", JSON.stringify(remainingAssignments))
      setPersonnelAssignments(
        remainingAssignments.filter((assignment: any) => assignment.subDepartmentId === subDepartmentId),
      )
    }
  }

  const getUserDetails = (userId: number) => {
    return allUsers.find((user) => user.id === userId)
  }

  const availableUsersForAssignment = allUsers.filter(
    (user) => !personnelAssignments.some((assignment) => assignment.userId === user.id),
  )

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <Button variant="ghost" onClick={onBack} className="-ml-2 mb-2">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Vissza az alosztályokhoz
          </Button>
          <h1 className="text-3xl font-bold">{subDepartmentName} Személyzet</h1>
          <p className="text-muted-foreground">Személyzet kezelése az alosztályban</p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => setEditingAssignment(null)}>
              <Plus className="w-4 h-4 mr-2" />
              Új tag hozzárendelése
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>{editingAssignment ? "Hozzárendelés szerkesztése" : "Új tag hozzárendelése"}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="user-select">Felhasználó</Label>
                <Select
                  value={selectedUserId}
                  onValueChange={setSelectedUserId}
                  required
                  disabled={!!editingAssignment}
                >
                  <SelectTrigger id="user-select">
                    <SelectValue placeholder="Válasszon felhasználót" />
                  </SelectTrigger>
                  <SelectContent>
                    {availableUsersForAssignment.map((user) => (
                      <SelectItem key={user.id} value={user.id.toString()}>
                        {user.name} ({user.rank})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="assignment-notes">Megjegyzés a hozzárendeléshez (opcionális)</Label>
                <Textarea
                  id="assignment-notes"
                  value={assignmentNotes}
                  onChange={(e) => setAssignmentNotes(e.target.value)}
                  rows={3}
                  placeholder="Megjegyzések ehhez a hozzárendeléshez..."
                />
              </div>
              <div className="flex gap-2">
                <Button type="button" variant="outline" onClick={resetForm} className="flex-1 bg-transparent">
                  Mégse
                </Button>
                <Button type="submit" className="flex-1">
                  {editingAssignment ? "Frissítés" : "Hozzáadás"}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>{subDepartmentName} Személyzet</CardTitle>
        </CardHeader>
        <CardContent>
          {personnelAssignments.length === 0 ? (
            <p className="text-muted-foreground text-center py-4">Még nincsenek személyek ebben az alosztályban.</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Név</TableHead>
                  <TableHead>Beosztás</TableHead>
                  <TableHead>Jelvényszám</TableHead>
                  <TableHead>Hozzárendelve</TableHead>
                  <TableHead>Megjegyzés</TableHead>
                  <TableHead>Kezelés</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {personnelAssignments.map((assignment) => {
                  const user = getUserDetails(assignment.userId)
                  if (!user) return null

                  return (
                    <TableRow key={assignment.id}>
                      <TableCell className="font-medium">{user.name}</TableCell>
                      <TableCell>{user.rank}</TableCell>
                      <TableCell>{user.badgeNumber || "N/A"}</TableCell>
                      <TableCell>{new Date(assignment.assignedAt).toLocaleDateString()}</TableCell>
                      <TableCell className="max-w-xs truncate">{assignment.notes || "Nincs megjegyzés"}</TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button variant="outline" size="sm" onClick={() => handleEdit(assignment)}>
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button variant="outline" size="sm" onClick={() => handleDelete(assignment.id)}>
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
