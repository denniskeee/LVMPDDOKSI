"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Plus, Edit, Trash2, Shield, CheckCircle } from "lucide-react"

export function SeizedCarsPage() {
  const [seizedCars, setSeizedCars] = useState<any[]>([])
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [editingCar, setEditingCar] = useState<any>(null)
  const [formData, setFormData] = useState({
    make: "",
    model: "",
    licensePlate: "",
    vin: "",
    color: "",
    seizedDate: "",
    seizedBy: "",
    reason: "",
    location: "",
    status: "impounded",
    releaseDate: "",
    notes: "",
  })

  useEffect(() => {
    const savedSeizedCars = JSON.parse(localStorage.getItem("seizedCars") || "[]")
    setSeizedCars(savedSeizedCars)
  }, [])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (editingCar) {
      const updatedCars = seizedCars.map((car) => (car.id === editingCar.id ? { ...car, ...formData } : car))
      setSeizedCars(updatedCars)
      localStorage.setItem("seizedCars", JSON.stringify(updatedCars))
    } else {
      const newCar = {
        ...formData,
        id: Date.now(),
        addedAt: new Date().toISOString(),
      }
      const updatedCars = [...seizedCars, newCar]
      setSeizedCars(updatedCars)
      localStorage.setItem("seizedCars", JSON.stringify(updatedCars))
    }

    resetForm()
  }

  const resetForm = () => {
    setFormData({
      make: "",
      model: "",
      licensePlate: "",
      vin: "",
      color: "",
      seizedDate: "",
      seizedBy: "",
      reason: "",
      location: "",
      status: "impounded",
      releaseDate: "",
      notes: "",
    })
    setEditingCar(null)
    setIsAddDialogOpen(false)
  }

  const handleEdit = (car: any) => {
    setEditingCar(car)
    setFormData({
      make: car.make,
      model: car.model,
      licensePlate: car.licensePlate,
      vin: car.vin,
      color: car.color,
      seizedDate: car.seizedDate,
      seizedBy: car.seizedBy,
      reason: car.reason,
      location: car.location,
      status: car.status,
      releaseDate: car.releaseDate || "",
      notes: car.notes || "",
    })
    setIsAddDialogOpen(true)
  }

  const handleDelete = (id: number) => {
    const updatedCars = seizedCars.filter((car) => car.id !== id)
    setSeizedCars(updatedCars)
    localStorage.setItem("seizedCars", JSON.stringify(updatedCars))
  }

  const handleRelease = (car: any) => {
    const updatedCars = seizedCars.map((c) =>
      c.id === car.id ? { ...c, status: "released", releaseDate: new Date().toISOString().split("T")[0] } : c,
    )
    setSeizedCars(updatedCars)
    localStorage.setItem("seizedCars", JSON.stringify(updatedCars))
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "impounded":
        return "destructive"
      case "released":
        return "default"
      case "pending-release":
        return "secondary"
      case "evidence":
        return "outline"
      default:
        return "secondary"
    }
  }

  const impoundedVehicles = seizedCars.filter((car) => car.status !== "released")
  const issuedVehicles = seizedCars.filter((car) => car.status === "released")

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Lefoglalt Járművek</h1>
          <p className="text-muted-foreground">Lefoglalt és elkobzott járművek nyomon követése</p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => setEditingCar(null)}>
              <Plus className="w-4 h-4 mr-2" />
              Új lefoglalt jármű hozzáadása
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingCar ? "Lefoglalt jármű szerkesztése" : "Új lefoglalt jármű hozzáadása"}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="make">Gyártó</Label>
                  <Input
                    id="make"
                    value={formData.make}
                    onChange={(e) => setFormData((prev) => ({ ...prev, make: e.target.value }))}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="model">Típus</Label>
                  <Input
                    id="model"
                    value={formData.model}
                    onChange={(e) => setFormData((prev) => ({ ...prev, model: e.target.value }))}
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="licensePlate">Rendszám</Label>
                  <Input
                    id="licensePlate"
                    value={formData.licensePlate}
                    onChange={(e) => setFormData((prev) => ({ ...prev, licensePlate: e.target.value }))}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="color">Szín</Label>
                  <Input
                    id="color"
                    value={formData.color}
                    onChange={(e) => setFormData((prev) => ({ ...prev, color: e.target.value }))}
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="vin">Alvázszám(ID)</Label>
                <Input
                  id="vin"
                  value={formData.vin}
                  onChange={(e) => setFormData((prev) => ({ ...prev, vin: e.target.value }))}
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="seizedDate">Lefoglalás dátuma</Label>
                  <Input
                    id="seizedDate"
                    type="date"
                    value={formData.seizedDate}
                    onChange={(e) => setFormData((prev) => ({ ...prev, seizedDate: e.target.value }))}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="seizedBy">Lefoglalta</Label>
                  <Input
                    id="seizedBy"
                    value={formData.seizedBy}
                    onChange={(e) => setFormData((prev) => ({ ...prev, seizedBy: e.target.value }))}
                    placeholder="Tiszt neve"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="reason">Lefoglalás oka</Label>
                <Textarea
                  id="reason"
                  value={formData.reason}
                  onChange={(e) => setFormData((prev) => ({ ...prev, reason: e.target.value }))}
                  placeholder="Írja le a lefoglalás okát..."
                  rows={3}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="location">Tárolási hely</Label>
                <Input
                  id="location"
                  value={formData.location}
                  onChange={(e) => setFormData((prev) => ({ ...prev, location: e.target.value }))}
                  placeholder="Tárolási létesítmény vagy telep"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="status">Státusz</Label>
                  <Select
                    value={formData.status}
                    onValueChange={(value) => setFormData((prev) => ({ ...prev, status: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="impounded">Lefoglalva</SelectItem>
                      <SelectItem value="pending-release">Kiadásra vár</SelectItem>
                      <SelectItem value="released">Kiadva</SelectItem>
                      <SelectItem value="evidence">Bizonyíték</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="releaseDate">Kiadás dátuma</Label>
                  <Input
                    id="releaseDate"
                    type="date"
                    value={formData.releaseDate}
                    onChange={(e) => setFormData((prev) => ({ ...prev, releaseDate: e.target.value }))}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="notes">Megjegyzések</Label>
                <Textarea
                  id="notes"
                  value={formData.notes}
                  onChange={(e) => setFormData((prev) => ({ ...prev, notes: e.target.value }))}
                  placeholder="További megjegyzések vagy megfigyelések..."
                  rows={3}
                />
              </div>

              <div className="flex gap-2">
                <Button type="button" variant="outline" onClick={resetForm} className="flex-1 bg-transparent">
                  Mégse
                </Button>
                <Button type="submit" className="flex-1">
                  {editingCar ? "Frissítés" : "Hozzáadás"}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Összes lefoglalt</CardTitle>
            <Shield className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{seizedCars.length}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Lefoglalva</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">
              {impoundedVehicles.filter((c) => c.status === "impounded").length}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Kiadásra vár</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">
              {impoundedVehicles.filter((c) => c.status === "pending-release").length}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Kiadva</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{issuedVehicles.length}</div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Lefoglalt járművek</CardTitle>
        </CardHeader>
        <CardContent>
          {impoundedVehicles.length === 0 ? (
            <p className="text-muted-foreground text-center py-4">Nincsenek lefoglalt járművek.</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Jármű</TableHead>
                  <TableHead>Rendszám</TableHead>
                  <TableHead>Lefoglalás dátuma</TableHead>
                  <TableHead>Lefoglalta</TableHead>
                  <TableHead>Státusz</TableHead>
                  <TableHead>Tárolási hely</TableHead>
                  <TableHead>Műveletek</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {impoundedVehicles.map((car) => (
                  <TableRow key={car.id}>
                    <TableCell className="font-medium">
                      {car.make} {car.model} ({car.color})
                    </TableCell>
                    <TableCell>{car.licensePlate}</TableCell>
                    <TableCell>{car.seizedDate}</TableCell>
                    <TableCell>{car.seizedBy}</TableCell>
                    <TableCell>
                      <Badge variant={getStatusColor(car.status)}>
                        {car.status === "impounded"
                          ? "Lefoglalva"
                          : car.status === "pending-release"
                            ? "Kiadásra vár"
                            : "Bizonyíték"}
                      </Badge>
                    </TableCell>
                    <TableCell>{car.location}</TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" onClick={() => handleEdit(car)}>
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleRelease(car)}
                          className="text-green-600 hover:text-green-700"
                        >
                          <CheckCircle className="w-4 h-4" />
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => handleDelete(car.id)}>
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Kiadott Járművek</CardTitle>
          <p className="text-muted-foreground">A rendszerből kiadott járművek listája</p>
        </CardHeader>
        <CardContent>
          {issuedVehicles.length === 0 ? (
            <p className="text-muted-foreground text-center py-4">Még nincsenek kiadott járművek.</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Jármű</TableHead>
                  <TableHead>Rendszám</TableHead>
                  <TableHead>Lefoglalás dátuma</TableHead>
                  <TableHead>Lefoglalta</TableHead>
                  <TableHead>Kiadás dátuma</TableHead>
                  <TableHead>Tárolási hely</TableHead>
                  <TableHead>Műveletek</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {issuedVehicles.map((car) => (
                  <TableRow key={car.id}>
                    <TableCell className="font-medium">
                      {car.make} {car.model} ({car.color})
                    </TableCell>
                    <TableCell>{car.licensePlate}</TableCell>
                    <TableCell>{car.seizedDate}</TableCell>
                    <TableCell>{car.seizedBy}</TableCell>
                    <TableCell>{car.releaseDate || "N/A"}</TableCell>
                    <TableCell>{car.location}</TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" onClick={() => handleEdit(car)}>
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => handleDelete(car.id)}>
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
