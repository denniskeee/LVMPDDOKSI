"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { CheckCircle, Clock, Users, XCircle, Crown } from "lucide-react"

export function UserManagementPage() {
  const [users, setUsers] = useState<any[]>([])

  useEffect(() => {
    const savedUsers = JSON.parse(localStorage.getItem("users") || "[]")
    setUsers(savedUsers)
  }, [])

  const approvedUsers = users.filter((user) => user.approved)
  const pendingUsers = users.filter((user) => !user.approved)

  const handleApproveUser = (userId: number) => {
    const updatedUsers = users.map((user) =>
      user.id === userId ? { ...user, approved: true, approvedAt: new Date().toISOString() } : user,
    )
    setUsers(updatedUsers)
    localStorage.setItem("users", JSON.stringify(updatedUsers))
  }

  const handleRejectUser = (userId: number) => {
    const updatedUsers = users.filter((user) => user.id !== userId)
    setUsers(updatedUsers)
    localStorage.setItem("users", JSON.stringify(updatedUsers))
  }

  const handleToggleLeaderStatus = (userId: number) => {
    const updatedUsers = users.map((user) => (user.id === userId ? { ...user, isLeader: !user.isLeader } : user))
    setUsers(updatedUsers)
    localStorage.setItem("users", JSON.stringify(updatedUsers))
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Felhasználók Kezelése</h1>
        <p className="text-muted-foreground">Felhasználói regisztrációk jóváhagyása és kezelése</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Összes Felhasználó</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{users.length}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Jóváhagyott</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{approvedUsers.length}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Jóváhagyásra vár</CardTitle>
            <Clock className="h-4 w-4 text-yellow-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">{pendingUsers.length}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Vezetők</CardTitle>
            <Crown className="h-4 w-4 text-yellow-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">{approvedUsers.filter((u) => u.isLeader).length}</div>
            <p className="text-xs text-muted-foreground">Vezetői pozícióban</p>
          </CardContent>
        </Card>
      </div>

      {/* Pending User Registrations */}
      {pendingUsers.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5" />
              Jóváhagyásra váró regisztrációk ({pendingUsers.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Név</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Beosztás</TableHead>
                  <TableHead>Jelvényszám</TableHead>
                  <TableHead>Regisztráció dátuma</TableHead>
                  <TableHead>Műveletek</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {pendingUsers.map((user) => (
                  <TableRow key={user.id}>
                    <TableCell className="font-medium">{user.name}</TableCell>
                    <TableCell>{user.email}</TableCell>
                    <TableCell>{user.rank}</TableCell>
                    <TableCell>{user.badgeNumber}</TableCell>
                    <TableCell>{user.joinedDate}</TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          onClick={() => handleApproveUser(user.id)}
                          className="bg-green-600 hover:bg-green-700"
                        >
                          <CheckCircle className="w-4 h-4 mr-1" />
                          Jóváhagyás
                        </Button>
                        <Button size="sm" variant="destructive" onClick={() => handleRejectUser(user.id)}>
                          <XCircle className="w-4 h-4 mr-1" />
                          Elutasítás
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      {/* No pending registrations message */}
      {pendingUsers.length === 0 && (
        <Card>
          <CardContent className="text-center py-8">
            <CheckCircle className="h-12 w-12 mx-auto text-green-600 mb-4" />
            <h3 className="text-lg font-medium mb-2">Nincsenek függőben lévő regisztrációk</h3>
            <p className="text-muted-foreground">Minden regisztráció fel van dolgozva.</p>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Összes Felhasználó</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Név</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Beosztás</TableHead>
                <TableHead>Jelvényszám</TableHead>
                <TableHead>Csatlakozás Dátuma</TableHead>
                <TableHead>Státusz</TableHead>
                <TableHead>Hibapont</TableHead>
                <TableHead>Műveletek</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {users.map((user) => (
                <TableRow key={user.id}>
                  <TableCell className="font-medium">
                    <div className="flex items-center gap-2">
                      {user.name}
                      {user.isAdmin && (
                        <Badge variant="destructive" className="text-xs">
                          Admin
                        </Badge>
                      )}
                      {user.isLeader && <Crown className="h-4 w-4 text-yellow-500" title="Vezető" />}
                    </div>
                  </TableCell>
                  <TableCell>{user.email}</TableCell>
                  <TableCell>{user.rank}</TableCell>
                  <TableCell>{user.badgeNumber}</TableCell>
                  <TableCell>{user.joinedDate}</TableCell>
                  <TableCell>
                    <Badge variant={user.approved ? "default" : "secondary"}>
                      {user.approved ? "Jóváhagyva" : "Jóváhagyás függőben"}
                    </Badge>
                  </TableCell>
                  <TableCell>{user.penaltyPoints || 0}</TableCell>
                  <TableCell>
                    {user.approved && !user.isAdmin && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleToggleLeaderStatus(user.id)}
                        title={user.isLeader ? "Vezetői státusz eltávolítása" : "Vezetői státusz hozzáadása"}
                      >
                        <Crown className={`h-4 w-4 ${user.isLeader ? "text-yellow-500" : "text-muted-foreground"}`} />
                      </Button>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
