"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { FileText, X, ImageIcon } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"

interface ReportsPageProps {
  user: any
}

export function ReportsPage({ user }: ReportsPageProps) {
  const [reports, setReports] = useState<any[]>([])
  const [allUsers, setAllUsers] = useState<any[]>([])
  const [selectedUserFilter, setSelectedUserFilter] = useState<string>("Összes felhasználó")
  const [selectedImages, setSelectedImages] = useState<string[]>([])
  const [showImageDialog, setShowImageDialog] = useState(false)
  const [selectedImageForView, setSelectedImageForView] = useState<string>("")
  const [formData, setFormData] = useState({
    name: user.name,
    rankBadgeNumber: `${user.rank} / ${user.badgeNumber || "N/A"}`,
    penalties: "",
    evidence: "",
    images: [] as string[],
  })

  const [showReportDialog, setShowReportDialog] = useState(false)
  const [selectedReport, setSelectedReport] = useState<any>(null)

  useEffect(() => {
    const savedReports = JSON.parse(localStorage.getItem("reports") || "[]")
    setReports(savedReports)

    if (user.isAdmin) {
      const users = JSON.parse(localStorage.getItem("users") || "[]")
      const approvedUsers = users.filter((u: any) => u.approved)
      setAllUsers(approvedUsers)
    }
  }, [user.isAdmin])

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files) return

    Array.from(files).forEach((file) => {
      if (file.type.startsWith("image/")) {
        const reader = new FileReader()
        reader.onload = (event) => {
          const base64String = event.target?.result as string
          setSelectedImages((prev) => [...prev, base64String])
        }
        reader.readAsDataURL(file)
      }
    })
  }

  const removeImage = (index: number) => {
    setSelectedImages((prev) => prev.filter((_, i) => i !== index))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    const newReport = {
      ...formData,
      images: selectedImages,
      id: Date.now(),
      submittedBy: user.name,
      submittedAt: new Date().toISOString(),
    }

    const updatedReports = [newReport, ...reports]
    setReports(updatedReports)
    localStorage.setItem("reports", JSON.stringify(updatedReports))

    setFormData((prev) => ({
      ...prev,
      penalties: "",
      evidence: "",
      images: [],
    }))
    setSelectedImages([])
  }

  const viewImage = (imageBase64: string) => {
    setSelectedImageForView(imageBase64)
    setShowImageDialog(true)
  }

  const viewReportDetails = (report: any) => {
    setSelectedReport(report)
    setShowReportDialog(true)
  }

  const filteredReports = reports.filter((report) => {
    if (user.isAdmin) {
      if (selectedUserFilter === "Összes felhasználó") {
        return true
      }
      return report.submittedBy === selectedUserFilter
    } else {
      return report.submittedBy === user.name
    }
  })

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Jelentés</h1>
        <p className="text-muted-foreground">Jelentések beküldése és beküldési előzmények megtekintése</p>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Új jelentés létrehozása</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Név</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData((prev) => ({ ...prev, name: e.target.value }))}
                  required
                  disabled
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="rankBadgeNumber">Beosztás / Jelvényszám</Label>
                <Input
                  id="rankBadgeNumber"
                  value={formData.rankBadgeNumber}
                  onChange={(e) => setFormData((prev) => ({ ...prev, rankBadgeNumber: e.target.value }))}
                  required
                  disabled
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="penalties">Büntetések</Label>
                <Textarea
                  id="penalties"
                  value={formData.penalties}
                  onChange={(e) => setFormData((prev) => ({ ...prev, penalties: e.target.value }))}
                  placeholder="Büntetések leírása..."
                  rows={4}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="evidence">Történtek leírása</Label>
                <Textarea
                  id="evidence"
                  value={formData.evidence}
                  onChange={(e) => setFormData((prev) => ({ ...prev, evidence: e.target.value }))}
                  placeholder="Események leírása..."
                  rows={3}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="images">Képek feltöltése</Label>
                <Input
                  id="images"
                  type="file"
                  accept="image/*"
                  multiple
                  onChange={handleImageUpload}
                  className="cursor-pointer"
                />
                <p className="text-xs text-muted-foreground">
                  Több kép is feltölthető. Támogatott formátumok: JPG, PNG, GIF
                </p>
              </div>

              {selectedImages.length > 0 && (
                <div className="space-y-2">
                  <Label>Feltöltött képek ({selectedImages.length})</Label>
                  <div className="grid grid-cols-2 gap-2">
                    {selectedImages.map((image, index) => (
                      <div key={index} className="relative group">
                        <img
                          src={image || "/placeholder.svg"}
                          alt={`Feltöltött kép ${index + 1}`}
                          className="w-full h-20 object-cover rounded border cursor-pointer hover:opacity-80"
                          onClick={() => viewImage(image)}
                        />
                        <Button
                          type="button"
                          variant="destructive"
                          size="sm"
                          className="absolute top-1 right-1 h-6 w-6 p-0 opacity-0 group-hover:opacity-100 transition-opacity"
                          onClick={() => removeImage(index)}
                        >
                          <X className="h-3 w-3" />
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <Button type="submit" className="w-full">
                <FileText className="w-4 h-4 mr-2" />
                Jelentés Leadása
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Legutóbbi jelentéseim</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4 max-h-96 overflow-y-auto">
              {reports.filter((req) => req.submittedBy === user.name).length === 0 ? (
                <p className="text-muted-foreground text-center py-4">Még nincsenek beküldött jelentéseid</p>
              ) : (
                reports
                  .filter((req) => req.submittedBy === user.name)
                  .slice(0, 5)
                  .map((report) => (
                    <div key={report.id} className="border rounded-lg p-3">
                      <div className="flex justify-between items-start mb-2">
                        <h4 className="font-medium">{report.name}</h4>
                      </div>
                      <p className="text-sm text-muted-foreground mb-1">{report.rankBadgeNumber}</p>
                      <p className="text-sm">{report.penalties.substring(0, 100)}...</p>
                      {report.images && report.images.length > 0 && (
                        <div className="flex items-center gap-1 mt-2">
                          <ImageIcon className="w-4 h-4 text-muted-foreground" />
                          <span className="text-xs text-muted-foreground">{report.images.length} kép csatolva</span>
                        </div>
                      )}
                      <p className="text-xs text-muted-foreground mt-2">
                        {new Date(report.submittedAt).toLocaleString()}
                      </p>
                    </div>
                  ))
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Összes Jelentés</CardTitle>
          {user.isAdmin && (
            <div className="flex items-center gap-2">
              <Label htmlFor="user-filter">Felhasználó szűrése:</Label>
              <Select value={selectedUserFilter} onValueChange={setSelectedUserFilter}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Válasszon felhasználót" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Összes felhasználó">Összes felhasználó</SelectItem>
                  {allUsers.map((u) => (
                    <SelectItem key={u.id} value={u.name}>
                      {u.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}
        </CardHeader>
        <CardContent>
          {filteredReports.length === 0 ? (
            <p className="text-muted-foreground text-center py-4">
              {user.isAdmin && selectedUserFilter !== "Összes felhasználó"
                ? `Nincsenek jelentések a(z) ${selectedUserFilter} felhasználótól.`
                : "Még nincsenek beküldött jelentések."}
            </p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Név</TableHead>
                  <TableHead>Beosztás / Jelvényszám</TableHead>
                  <TableHead>Büntetések</TableHead>
                  <TableHead>Bizonyítékok</TableHead>
                  <TableHead>Képek</TableHead>
                  <TableHead>Beküldve</TableHead>
                  {user.isAdmin && <TableHead>Beküldte</TableHead>}
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredReports.map((report) => (
                  <TableRow
                    key={report.id}
                    className="cursor-pointer hover:bg-muted/50"
                    onClick={() => viewReportDetails(report)}
                  >
                    <TableCell className="font-medium">{report.name}</TableCell>
                    <TableCell>{report.rankBadgeNumber}</TableCell>
                    <TableCell className="max-w-xs truncate">{report.penalties}</TableCell>
                    <TableCell className="max-w-xs truncate">{report.evidence || "Nincs leírás"}</TableCell>
                    <TableCell>
                      {report.images && report.images.length > 0 ? (
                        <div className="flex items-center gap-2">
                          <div className="flex gap-1">
                            {report.images.slice(0, 3).map((image: string, index: number) => (
                              <img
                                key={index}
                                src={image || "/placeholder.svg"}
                                alt={`Kép ${index + 1}`}
                                className="w-12 h-12 object-cover rounded border cursor-pointer hover:scale-105 transition-transform shadow-sm"
                                onClick={() => viewImage(image)}
                              />
                            ))}
                          </div>
                          {report.images.length > 3 && (
                            <span className="text-xs text-muted-foreground font-medium">
                              +{report.images.length - 3}
                            </span>
                          )}
                          <span className="text-xs text-muted-foreground">({report.images.length} kép)</span>
                        </div>
                      ) : (
                        <span className="text-muted-foreground text-sm">Nincs kép</span>
                      )}
                    </TableCell>
                    <TableCell>{new Date(report.submittedAt).toLocaleDateString()}</TableCell>
                    {user.isAdmin && <TableCell>{report.submittedBy}</TableCell>}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Report Details Dialog */}
      <Dialog open={showReportDialog} onOpenChange={setShowReportDialog}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Jelentés részletei</DialogTitle>
          </DialogHeader>
          {selectedReport && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-sm font-medium text-muted-foreground">Név</Label>
                  <p className="text-lg font-medium">{selectedReport.name}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-muted-foreground">Beosztás / Jelvényszám</Label>
                  <p className="text-lg">{selectedReport.rankBadgeNumber}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-sm font-medium text-muted-foreground">Beküldve</Label>
                  <p className="text-lg">{new Date(selectedReport.submittedAt).toLocaleString()}</p>
                </div>
              </div>

              {user.isAdmin && (
                <div>
                  <Label className="text-sm font-medium text-muted-foreground">Beküldte</Label>
                  <p className="text-lg">{selectedReport.submittedBy}</p>
                </div>
              )}

              <div>
                <Label className="text-sm font-medium text-muted-foreground">Büntetések</Label>
                <div className="mt-2 p-4 bg-muted rounded-lg">
                  <p className="whitespace-pre-wrap">{selectedReport.penalties}</p>
                </div>
              </div>

              {selectedReport.evidence && (
                <div>
                  <Label className="text-sm font-medium text-muted-foreground">Történtek leírása</Label>
                  <div className="mt-2 p-4 bg-muted rounded-lg">
                    <p className="whitespace-pre-wrap">{selectedReport.evidence}</p>
                  </div>
                </div>
              )}

              {selectedReport.images && selectedReport.images.length > 0 && (
                <div>
                  <Label className="text-sm font-medium text-muted-foreground">
                    Csatolt képek ({selectedReport.images.length})
                  </Label>
                  <div className="mt-2 grid grid-cols-2 md:grid-cols-3 gap-3">
                    {selectedReport.images.map((image: string, index: number) => (
                      <div key={index} className="relative group">
                        <img
                          src={image || "/placeholder.svg"}
                          alt={`Csatolt kép ${index + 1}`}
                          className="w-full h-32 object-cover rounded border cursor-pointer hover:opacity-80 transition-opacity"
                          onClick={() => {
                            setShowReportDialog(false)
                            viewImage(image)
                          }}
                        />
                        <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-20 transition-all rounded flex items-center justify-center">
                          <span className="text-white opacity-0 group-hover:opacity-100 text-sm font-medium">
                            Nagyítás
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Image View Dialog */}
      <Dialog open={showImageDialog} onOpenChange={setShowImageDialog}>
        <DialogContent className="max-w-6xl max-h-[90vh] p-2">
          <DialogHeader className="pb-2">
            <DialogTitle>Kép megtekintése</DialogTitle>
          </DialogHeader>
          <div className="flex justify-center items-center bg-gray-50 dark:bg-gray-900 rounded-lg p-4">
            <img
              src={selectedImageForView || "/placeholder.svg"}
              alt="Nagyított kép"
              className="max-w-full max-h-[75vh] object-contain rounded shadow-lg"
            />
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
