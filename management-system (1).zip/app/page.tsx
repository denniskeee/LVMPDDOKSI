"use client"

import { useState, useEffect } from "react"
import { SystemSetup } from "@/components/system-setup"
import { LoginForm } from "@/components/login-form"
import { RegistrationForm } from "@/components/registration-form"
import { Dashboard } from "@/components/dashboard"

export default function Home() {
  const [currentUser, setCurrentUser] = useState<any>(null)
  const [isSystemSetup, setIsSystemSetup] = useState(false)
  const [showRegistration, setShowRegistration] = useState(false)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Check if system is already set up
    const systemSetup = localStorage.getItem("systemSetup")
    const savedUser = localStorage.getItem("currentUser")

    if (systemSetup === "true") {
      setIsSystemSetup(true)
      if (savedUser) {
        setCurrentUser(JSON.parse(savedUser))
      }
    }
    setIsLoading(false)
  }, [])

  const handleSetupComplete = () => {
    setIsSystemSetup(true)
    const savedUser = localStorage.getItem("currentUser")
    if (savedUser) {
      setCurrentUser(JSON.parse(savedUser))
    }
  }

  const handleLogin = (user: any) => {
    setCurrentUser(user)
  }

  const handleLogout = () => {
    setCurrentUser(null)
    localStorage.removeItem("currentUser")
  }

  const handleRegistrationComplete = () => {
    setShowRegistration(false)
    // Show success message or redirect to login
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600" />
      </div>
    )
  }

  if (!isSystemSetup) {
    return <SystemSetup onSetupComplete={handleSetupComplete} />
  }

  if (currentUser) {
    return <Dashboard user={currentUser} onLogout={handleLogout} />
  }

  if (showRegistration) {
    return (
      <RegistrationForm
        onRegistrationComplete={handleRegistrationComplete}
        onShowLogin={() => setShowRegistration(false)}
      />
    )
  }

  return <LoginForm onLogin={handleLogin} onShowRegistration={() => setShowRegistration(true)} />
}
